import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDate;

public class Main {
    
    public static PrintWriter writer;
    public static void main(String[] args) throws FileNotFoundException {

        String[] linesInput = ReadFromFile.readFile(args[0]);

        // Convert the input file to a 2D string array
        int numRows = linesInput.length;
        int numCols = 10;
        String[][] inputList = new String[numRows][numCols];

        Library myLibrary = new Library();

        // Initialize the id of books and members
        int idOfBook = 1;
        int idOfMember = 1;

        for (int i = 0; i < numRows; i++) {
            String[] lineString = linesInput[i].split("\t");
            inputList[i] = lineString;
        }
        
        // Create a new PrintWriter object to write to the output file
        writer = new PrintWriter(args[1]);

        // Iterate the input list to execute commands
        for (String[] line: inputList){
            String command = line[0];
            switch (command){
                case "addBook":{
                    // Create a new book object and add to the bookList
                    Book book = new Book(idOfBook, line[1]);
                    myLibrary.addBook(book);

                    if(line[1].equals("P")){
                        writer.println("Created new book: Printed [id: " + idOfBook + "]" );
                    }else{
                        writer.println("Created new book: Handwritten [id: " + idOfBook + "]" );
                    }
                    idOfBook += 1;
                    break;
                }

                case "addMember":{

                    // Create a new member object and add to the memberList
                    Member member = new Member(idOfMember, line[1]);
                    myLibrary.addMember(member);

                    if(line[1].equals("S")){
                        writer.println("Created new member: Student [id: " + idOfMember + "]");
                    }else{
                        writer.println("Created new member: Academic [id: " + idOfMember + "]");
                    }
                    idOfMember += 1;
                    break;
                }

                case "borrowBook":
                {
                    // Determine book which will be borrowed
                    int requestedBookId = Integer.parseInt(line[1]);
                    Book requestedBook = Library.bookList.get(requestedBookId -1);
                    LocalDate date = LocalDate.parse(line[3]);

                    // Call method called 'borrowBook'
                    requestedBook.borrowBook(requestedBookId, Integer.parseInt(line[2]) ,date);
                    break;
                }
                case "returnBook":{

                    // Determine book which will be returned
                    int returnedBookId = Integer.parseInt(line[1]);
                    Book returnedBook = Library.bookList.get(returnedBookId -1);
                    LocalDate date = LocalDate.parse(line[3]);

                    // Call method called 'returnBook'
                    returnedBook.returnBook(returnedBookId, Integer.parseInt(line[2]),date );
                    break;
                }

                case "readInLibrary":{

                    // Determine book which will be read in library
                    int readInLibraryBookId = Integer.parseInt(line[1]);
                    Book readInLibraryBook = Library.bookList.get(readInLibraryBookId -1);
                    LocalDate date = LocalDate.parse(line[3]);

                    // Call method called 'readInLibraryBook'
                    readInLibraryBook.readInLibrary(readInLibraryBookId, Integer.parseInt(line[2]),date);
                    break;
                }
                case "extendBook":{

                    // Determine book which will be extended
                    int extendBookId = Integer.parseInt(line[1]);
                    Book bookToBeExtended = Library.bookList.get(extendBookId -1);
                    LocalDate date = LocalDate.parse(line[3]);

                    // Call method called 'extendBook'
                    bookToBeExtended.extendBook(extendBookId, Integer.parseInt(line[2]), date);
                    break;
                } case "getTheHistory":{
                    // Call method called 'getTheHistory'
                    myLibrary.getTheHistory();
                }
            }
        }
        writer.close();
    }
}