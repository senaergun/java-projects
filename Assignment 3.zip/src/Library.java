import java.util.ArrayList;
import java.util.List;

public class Library {
    // Create lists of objects to save info about registered books and members
    public static List<Book> bookList = new ArrayList<Book>();
    public static List<Member> memberList = new ArrayList<Member>();

    // Create method to add book to the bookList
    public void addBook(Book book){
        bookList.add(book);
    }

    // Create method to add member to the memberList
    public void addMember(Member member){memberList.add(member);}


    public void getTheHistory(){

        // Initialize the numbers of requested things
        int numStudents = 0;
        int numAcademics = 0;
        int numPrintedBooks = 0;
        int numHandwrittenBooks = 0;
        int numBorrowedBooks = 0;
        int numReadInLibraryBooks = 0;

        // Iterate the both lists to count requested things and write to the output file
        for(Member member: memberList){
            if(member.getType().equals("S")){
                numStudents += 1;
            }else{
                numAcademics += 1;
            }
        }

        for (Book book: bookList){
            if(book.getType().equals("P")){
                numPrintedBooks += 1;
            }if(book.getType().equals("H")){
                numHandwrittenBooks += 1;
            }if(book.isBorrowed){
                numBorrowedBooks += 1;
            }if(book.isReadInLibrary){
                numReadInLibraryBooks += 1;
            }
        }
        Main.writer.println("History of library:");
        Main.writer.println();
        Main.writer.println("Number of students: " + numStudents);
        for(Member member: memberList) {
            if (member.getType().equals("S")) {
                Main.writer.println("Student [id: " + member.getId() + "]");
            }
        }
        Main.writer.println();
        Main.writer.println("Number of academics: " + numAcademics);
        for(Member member: memberList){
            if (member.getType().equals("A")){
                Main.writer.println("Academic [id: " + member.getId() + "]");
            }
        }
        Main.writer.println();
        Main.writer.println("Number of printed books: " + numPrintedBooks);
        for (Book book: bookList){
            if (book.getType().equals("P")){
                Main.writer.println("Printed [id: " + book.getId() + "]");
            }
        }
        Main.writer.println();
        Main.writer.println("Number of handwritten books: " + numHandwrittenBooks);
        for (Book book: bookList){
            if (book.getType().equals("H")){
                Main.writer.println("Handwritten [id: " + book.getId() + "]");
            }
        }
        Main.writer.println();
        Main.writer.println("Number of borrowed books: " + numBorrowedBooks);
        for (Book book: bookList){
            if (book.isBorrowed){
                Main.writer.println(String.format("The book [%d] was borrowed by member [%d] at %s", book.getId(), book.getMemberId(),
                        book.getBorrowTime()));
            }
        }
        Main.writer.println();
        Main.writer.println("Number of books read in library: " + numReadInLibraryBooks);
        for (Book book: bookList){
            if (book.isReadInLibrary){
                Main.writer.println(String.format("The book [%d] was read in library by member [%d] at %s", book.getId(), book.getMemberId(),
                book.getReadInLibraryTime()));
            }
        }

    }
}
