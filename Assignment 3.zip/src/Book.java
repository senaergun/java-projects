import java.time.LocalDate;
import static java.time.temporal.ChronoUnit.DAYS;

public class Book extends Library {
    private int id;
    private String type;
    private LocalDate borrowTime;

    // keep a variable called 'memberId' to keep info about who borrowed this book
    private int memberId;
    private LocalDate deadline;
    private LocalDate readInLibraryTime;
    protected boolean isBorrowed = false;
    protected boolean isReadInLibrary = false;
    protected boolean isExtended = false;

    public int getMemberId() {
        return memberId;
    }
    public LocalDate getBorrowTime() {
        return borrowTime;
    }
    public String getType() {
        return type;
    }
    public int getId() {
        return id;
    }

    public LocalDate getReadInLibraryTime(){ return readInLibraryTime;}

    public Book(int id, String type){
        // Check if a book's id has a maximum of six digits
        if (Integer.toString(id).length() <=6){
            this.id = id;
        }
        else{
            Main.writer.println("The id of a book must be most a six digit number!");
        }
        this.type = type;
    }
    public void borrowBook(int idOfBook, int idOfMember, LocalDate date){
        // Check if the book is registered in the library
        if (idOfBook > Library.bookList.toArray().length){
            Main.writer.println("There is no such a book!");
        }
        // Check if the member is registered in the library
        else if(idOfMember > Library.memberList.toArray().length){
            Main.writer.println("There is no such a member!");
        }
        // Check if the book has been borrowed before
        else if (isBorrowed){
            Main.writer.println("You cannot borrow this book!");
        }
        // Check if the book is handwritten
        else if (this.type.equals("H")) {
            Main.writer.println("You cannot borrow this book!");
        }else{
            if(memberList.get(idOfMember -1 ).getType().equals("S")){

                // Check if the number of borrowed books by a student exceeds the borrowing limit
                if (memberList.get(idOfMember -1 ).getNumBorrowedBooks() >= 2){
                    Main.writer.println("You have exceeded the borrowing limit!");
                }else{

                    // Assign information to properties about book which will be borrowed and member who will borrow the book
                    int currentNumBorrowedBooks = memberList.get(idOfMember -1 ).getNumBorrowedBooks();
                    memberList.get(idOfMember -1 ).setNumBorrowedBooks(currentNumBorrowedBooks + 1);
                    isBorrowed = true;
                    memberId = idOfMember;
                    borrowTime = date;
                    isExtended = false;
                    deadline = borrowTime.plusDays(7);
                    Main.writer.println(String.format("The book [%d] was borrowed by member [%d] at %s", idOfBook
                    , idOfMember, date));
                }
            }else{
                // Check if the number of borrowed books by an academic exceeds the borrowing limit
                if (memberList.get(idOfMember -1 ).getNumBorrowedBooks() >= 4){
                    Main.writer.println("You have exceeded the borrowing limit!");
                }else{

                    // Assign information about borrowing to properties
                    int currentNumBorrowedBooks = memberList.get(idOfMember -1 ).getNumBorrowedBooks();
                    memberList.get(idOfMember -1 ).setNumBorrowedBooks(currentNumBorrowedBooks + 1);
                    isBorrowed = true;
                    memberId = idOfMember;
                    borrowTime = date;
                    isExtended = false;
                    deadline = borrowTime.plusDays(14);
                    Main.writer.println(String.format("The book [%d] was borrowed by member [%d] at %s", idOfBook
                            , idOfMember, date));
                }
            }
        }
    }
    public void readInLibrary(int idOfBook, int idOfMember, LocalDate date){

        // Check if the book is registered in the library
        if (idOfBook > Library.bookList.toArray().length){
            Main.writer.println("There is no such a book!");
        }
        // Check if the member is registered in the library
        else if(idOfMember > Library.memberList.toArray().length) {
            Main.writer.println("There is no such a member!");
        }
        // Check if the book is handwritten and member is a student
        else if(memberList.get(idOfMember -1 ).getType().equals("S") && bookList.get(idOfBook - 1).getType().equals("H")){
            Main.writer.println("Students can not read handwritten books!");
        }
        // Check if the book has been borrowed before
        else if (isBorrowed) {
            Main.writer.println("You can not read this book!");
        }else{
            // Assign information to properties about book which will be read and member who will read the book
            isReadInLibrary = true;
            memberId = idOfMember;
            readInLibraryTime = date;
            Main.writer.println(String.format("The book [%d] was read in library by member [%d] at %s", idOfBook ,idOfMember,
                    date));
        }

        }
    // Initialize the fee which members will pay as a penalty
    int fee = 0;
    public void returnBook(int idOfBook, int idOfMember, LocalDate date){
        // Check if the book is registered in the library
        if (idOfBook > Library.bookList.toArray().length){
            Main.writer.println("There is no such a book!");
        }
        // Check if the member is registered in the library
        else if(idOfMember > Library.memberList.toArray().length){
            Main.writer.println("There is no such a member!");
        }
        // Make sure the book which will be returned has been taken before
        else if (!isBorrowed && !isReadInLibrary)  {
            Main.writer.println("You cannot return this book!");
        }
        // Make sure member has the book which will be returned
        else if(this.memberId != idOfMember){
            Main.writer.println("Member does not have this book!");
        }
        // Do required calculations about penalty and print the message to the output
        else if (isBorrowed){
            if(date.isAfter(this.deadline)){
                int fee = (int) DAYS.between(this.deadline, date);
                Main.writer.println(String.format("The book [%d] was returned by member [%d] at %s Fee: %s", idOfBook,
                        idOfMember, date, fee));
            }else{
                Main.writer.println(String.format("The book [%d] was returned by member [%d] at %s Fee: %s", idOfBook,
                        idOfMember, date, fee));
            }
            isBorrowed = false;
            isExtended = false;
            int currentNumBorrowedBooks = memberList.get(idOfMember -1 ).getNumBorrowedBooks();
            memberList.get(idOfMember -1 ).setNumBorrowedBooks(currentNumBorrowedBooks - 1);
        }else{
            Main.writer.println(String.format("The book [%d] was returned by member [%d] at %s Fee: %s", idOfBook,
                    idOfMember, date, fee));
            isReadInLibrary = false;

        }
    }

    public void extendBook(int idOfBook, int idOfMember, LocalDate date){

        // Check if the current date is before the deadline
        if (date.isAfter(deadline)){
            Main.writer.println("You cannot extend the deadline!");
        }
        // Check if the same member has extended the deadline of the same book before
        else if (isExtended){
            Main.writer.println("You cannot extend the deadline!");
        }else{

            // Update the deadline
            if(memberList.get(idOfMember -1 ).getType().equals("S")){
                deadline = deadline.plusDays(7);
            }else{
                deadline = deadline.plusDays(14);
            }
            Main.writer.println(String.format("The deadline of book [%d] was extended by member [%d] at %s",idOfBook,
                    idOfMember, date));
            Main.writer.println(String.format("New deadline of book [%d] is %s", idOfBook, deadline));
            isExtended = true;

        }

    }
}
