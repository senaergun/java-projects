public class Member extends Library {
    private String type;
    private int id;
    private int numBorrowedBooks = 0;

    public int getNumBorrowedBooks() {
        return numBorrowedBooks;
    }

    public void setNumBorrowedBooks(int numBorrowedBooks) {
        this.numBorrowedBooks = numBorrowedBooks;
    }



    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public Member(int id, String type){
        // Check if a member's id has a maximum of six digits
        if (Integer.toString(id).length() <=6){
            this.id = id;
        }
        else{
            Main.writer.println("The id of a member must be most a six digit number!");
        }
        this.type = type;
    }
}