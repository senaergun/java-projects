
import javafx.animation.*;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.text.Text;
import javafx.util.Duration;
import javafx.scene.Cursor;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
public class DuckHunt extends Application implements EventHandler<ActionEvent> {
    public static final double SCALE = 3;
    public static final double VOLUME = 0.025;
    public static final int WINDOW_WIDTH = 280;
    public static final int WINDOW_HEIGHT = 260;
    private static final String FAVICON_PATH = "assets/favicon/1.png";
    private static final String INTRO_SOUND_PATH = "assets/effects/Intro.mp3";
    private static final String GUNSHOT_SOUND_PATH = "assets/effects/Gunshot.mp3";
    private static final String DUCK_FALLS_SOUND_PATH = "assets/effects/DuckFalls.mp3";
    private static final String GAME_OVER_SOUND_PATH = "assets/effects/GameOver.mp3";
    private static final String LEVEL_COMPLETED_SOUND_PATH = "assets/effects/LevelCompleted.mp3";
    private static final String GAME_COMPLETED_SOUND_PATH = "assets/effects/GameCompleted.mp3";
    private int ammoLeftLevel1 = 3;
    private int ammoLeftLevel2 = 3;
    private int ammoLeftLevel3 = 6;
    private int ammoLeftLevel4 = 6;
    private int ammoLeftLevel5 = 9;
    private int ammoLeftLevel6 = 12;
    private int duckLeftLevel1 = 1;
    private int duckLeftLevel2 = 1;
    private int duckLeftLevel3 = 2;
    private int duckLeftLevel4 = 2;
    private int duckLeftLevel5 = 3;
    private int duckLeftLevel6 = 4;
    Text levelText1;
    Text levelText2;
    Text levelText3;
    Text levelText4;
    Text levelText5;
    Text levelText6;
    Text ammoTextLevel1;
    Text ammoTextLevel2;
    Text ammoTextLevel3;
    Text ammoTextLevel4;
    Text ammoTextLevel5;
    Text ammoTextLevel6;
    private Timeline duckAnimation;
    private Timeline duckAnimationLevel2;
    private Timeline duck1AnimationLevel3;
    private Timeline duck2AnimationLevel3;
    private Timeline duck1AnimationLevel4;
    private Timeline duck2AnimationLevel4;
    private Timeline duck1AnimationLevel5;
    private Timeline duck2AnimationLevel5;
    private Timeline duck3AnimationLevel5;
    private Timeline duck1AnimationLevel6;
    private Timeline duck2AnimationLevel6;
    private Timeline duck3AnimationLevel6;
    private Timeline duck4AnimationLevel6;
    private ImageView duckImageView = new ImageView();
    private ImageView duckImageViewLevel2 = new ImageView();
    private ImageView duck1ImageViewLevel3 = new ImageView();
    private ImageView duck2ImageViewLevel3 = new ImageView();
    private ImageView duck1ImageViewLevel4 = new ImageView();
    private ImageView duck2ImageViewLevel4 = new ImageView();
    private ImageView duck1ImageViewLevel5 = new ImageView();
    private ImageView duck2ImageViewLevel5 = new ImageView();
    private ImageView duck3ImageViewLevel5 = new ImageView();
    private ImageView duck1ImageViewLevel6 = new ImageView();
    private ImageView duck2ImageViewLevel6 = new ImageView();
    private ImageView duck3ImageViewLevel6 = new ImageView();
    private ImageView duck4ImageViewLevel6 = new ImageView();
    private StackPane gamePane1;
    private StackPane gamePane2;
    private StackPane gamePane3;
    private StackPane gamePane4;
    private StackPane gamePane5;
    private StackPane gamePane6;
    AtomicBoolean isGoingRight1 = new AtomicBoolean(true);
    AtomicBoolean isGoingRight2 = new AtomicBoolean(true);
    AtomicBoolean isGoingRight3 = new AtomicBoolean(true);
    AtomicBoolean isGoingRight4 = new AtomicBoolean(true);
    AtomicBoolean isGoingDown1 = new AtomicBoolean(false);
    AtomicBoolean isGoingDown2 = new AtomicBoolean(false);
    AtomicBoolean isGoingDown3 = new AtomicBoolean(false);
    AtomicBoolean isGoingDown4 = new AtomicBoolean(false);
    AtomicBoolean isRightEdge1 = new AtomicBoolean(false);
    AtomicBoolean isRightEdge2 = new AtomicBoolean(false);
    AtomicBoolean isRightEdge3 = new AtomicBoolean(false);
    AtomicBoolean isRightEdge4 = new AtomicBoolean(false);
    AtomicBoolean isDownEdge1 = new AtomicBoolean(false);
    AtomicBoolean isDownEdge2 = new AtomicBoolean(false);
    AtomicBoolean isDownEdge3 = new AtomicBoolean(false);
    AtomicBoolean isDownEdge4 = new AtomicBoolean(false);
    private MediaPlayer mediaPlayer;
    Scene gameScene1;
    Scene gameScene2;
    Scene gameScene3;
    Scene gameScene4;
    Scene gameScene5;
    Scene gameScene6;
    private AtomicInteger selectedCrosshair = new AtomicInteger(1);
    private VBox textsGameOver;
    VBox levelCompletedText1 = createLevelCompletedText();
    VBox levelCompletedText2 = createLevelCompletedText();
    VBox levelCompletedText3 = createLevelCompletedText();
    VBox levelCompletedText4 = createLevelCompletedText();
    VBox levelCompletedText5 = createLevelCompletedText();
    ImageView selectionBackground = new ImageView();

    private HBox gameTexts;
    ImageView duckShotImage = new ImageView();
    ImageView duckFallImage = new ImageView();
    private boolean right;
    public static void main(String[] args) {
        launch(args);
    }

    /**
     *Starts the Duck Hunt game with the specified Stage.
     *@param window The Stage to display the game.
     *@throws Exception If an error occurs during the game startup.
     */

    @Override
    public void start(Stage window) throws Exception {
        /**
         *Sets up the main window and initializes different scenes for the game.
         *Uses JavaFX to create and display the graphical user interface.
         */
        // Set the title of the main window
        window.setTitle("HUBBM Duck Hunt");
        window.getIcons().add(new Image(Objects.requireNonNull(getClass().getResource(FAVICON_PATH)).toExternalForm()));

        // Set the favicon for the main window
        ImageView titlebackground = new ImageView(new Image(Objects.requireNonNull(getClass().getResource(FAVICON_PATH)).toExternalForm()));
        titlebackground.setFitWidth(WINDOW_WIDTH * SCALE);
        titlebackground.setFitHeight(WINDOW_HEIGHT * SCALE);

        Text titleText = CreateText.createBlinkingText("PRESS ENTER TO PLAY");
        Text exitText = CreateText.createBlinkingText("PRESS ESC TO EXIT");

        VBox textContainer = new VBox();
        textContainer.getChildren().addAll(titleText, exitText);
        textContainer.setAlignment(Pos.CENTER); // Center align the texts vertically and horizontally
        textContainer.setSpacing(10); // Set the spacing between the texts
        textContainer.setTranslateY(50 * SCALE); // Adjust the vertical position

        StackPane titlePane = new StackPane();
        titlePane.getChildren().addAll(titlebackground, textContainer);

        Scene titleScene = new Scene(titlePane, WINDOW_WIDTH * SCALE, WINDOW_HEIGHT * SCALE);


        ImageView crosshairIcon = new ImageView(new Image(Objects.requireNonNull(getClass().getResource("assets/crosshair/1.png")).toExternalForm()));
        crosshairIcon.setFitWidth(crosshairIcon.getImage().getWidth() * SCALE);
        crosshairIcon.setFitHeight(crosshairIcon.getImage().getHeight() * SCALE);

        Text navigateText = CreateText.createText("USE ARROW KEYS TO NAVIGATE");
        Text startText = CreateText.createText("PRESS ENTER TO START");
        Text exitTest = CreateText.createText("PRESS ESC TO EXIT");

        VBox texts = new VBox();
        texts.getChildren().addAll(navigateText, startText, exitTest);
        texts.setAlignment(Pos.CENTER);
        texts.setTranslateY(-100 * SCALE);

        StackPane crosshairPane = new StackPane();
        crosshairPane.getChildren().add(crosshairIcon);
        crosshairPane.setAlignment(Pos.CENTER);

        StackPane selectionPane = new StackPane();
        selectionPane.getChildren().addAll(selectionBackground, texts, crosshairPane);

        Scene backgroundSelectionScene = new Scene(selectionPane, WINDOW_WIDTH * SCALE, WINDOW_HEIGHT * SCALE);

        //game scene arrangement
        ImageView gameBackground1 = new ImageView();
        setSize(gameBackground1);

        ImageView gameBackground2 = new ImageView();
        setSize(gameBackground2);

        ImageView gameBackground3 = new ImageView();
        setSize(gameBackground3);

        ImageView gameBackground4 = new ImageView();
        setSize(gameBackground4);

        ImageView gameBackground5 = new ImageView();
        setSize(gameBackground5);

        ImageView gameBackground6 = new ImageView();
        setSize(gameBackground6);

        ImageView gameForeground1 = new ImageView();
        setSize(gameForeground1);

        ImageView gameForeground2 = new ImageView();
        setSize(gameForeground2);

        ImageView gameForeground3 = new ImageView();
        setSize(gameForeground3);

        ImageView gameForeground4 = new ImageView();
        setSize(gameForeground4);

        ImageView gameForeground5 = new ImageView();
        setSize(gameForeground5);

        ImageView gameForeground6 = new ImageView();
        setSize(gameForeground6);

        levelText1 = CreateText.createText("Level 1");
        setLevelText(levelText1);
        levelText2 = CreateText.createText("Level 2");
        setLevelText(levelText2);
        levelText3 = CreateText.createText("Level 3");
        setLevelText(levelText3);
        levelText4 = CreateText.createText("Level 4");
        setLevelText(levelText4);
        levelText5 = CreateText.createText("Level 5");
        setLevelText(levelText5);
        levelText6 = CreateText.createText("Level 6");
        setLevelText(levelText6);

        ammoTextLevel1 = CreateText.createText("Ammo Left: " + ammoLeftLevel1);
        setAmmoText(ammoTextLevel1);

        ammoTextLevel2 = CreateText.createText("Ammo Left: " + ammoLeftLevel1);
        setAmmoText(ammoTextLevel2);

        ammoTextLevel3 = CreateText.createText("Ammo Left: " + ammoLeftLevel1);
        setAmmoText(ammoTextLevel3);

        ammoTextLevel4 = CreateText.createText("Ammo Left: " + ammoLeftLevel1);
        setAmmoText(ammoTextLevel4);

        ammoTextLevel5 = CreateText.createText("Ammo Left: " + ammoLeftLevel1);
        setAmmoText(ammoTextLevel5);

        ammoTextLevel6 = CreateText.createText("Ammo Left: " + ammoLeftLevel1);
        setAmmoText(ammoTextLevel6);


        gamePane1 = new StackPane();
        gamePane2 = new StackPane();
        gamePane3 = new StackPane();
        gamePane4 = new StackPane();
        gamePane5 = new StackPane();
        gamePane6 = new StackPane();

        gameScene1 = new Scene(gamePane1, WINDOW_WIDTH * SCALE, WINDOW_HEIGHT * SCALE);
        gameScene2 = new Scene(gamePane2, WINDOW_WIDTH * SCALE, WINDOW_HEIGHT * SCALE);
        gameScene3 = new Scene(gamePane3, WINDOW_WIDTH * SCALE, WINDOW_HEIGHT * SCALE);
        gameScene4 = new Scene(gamePane4, WINDOW_WIDTH * SCALE, WINDOW_HEIGHT * SCALE);
        gameScene5 = new Scene(gamePane5, WINDOW_WIDTH * SCALE, WINDOW_HEIGHT * SCALE);
        gameScene6 = new Scene(gamePane6, WINDOW_WIDTH * SCALE, WINDOW_HEIGHT * SCALE);

        /**
         * Sets the event handlers for key presses in the title scene and background selection scene.
         */
        titleScene.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                window.close();
            }
            if (event.getCode() == KeyCode.ENTER) {
                selectionBackground.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/background/1.png")).toExternalForm()));
                //selection background arrangement
                selectionBackground.setFitWidth(WINDOW_WIDTH * SCALE);
                selectionBackground.setFitHeight(WINDOW_HEIGHT * SCALE);
                window.setScene(backgroundSelectionScene);
            }
        });

        AtomicInteger selectedBackground = new AtomicInteger(1);

        /**
         * Sets the event handlers for key presses in the background selection scene.
         */
        backgroundSelectionScene.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                window.setScene(titleScene);
            }if (event.getCode() == KeyCode.RIGHT) {
                selectedBackground.getAndIncrement();
                if (selectedBackground.get() > 6){
                    selectedBackground.set(1);
                }

            }if (event.getCode() == KeyCode.LEFT) {
                selectedBackground.getAndDecrement();
                if (selectedBackground.get() < 1){
                    selectedBackground.set(6);
                }

            }if (event.getCode() == KeyCode.UP) {
                selectedCrosshair.getAndIncrement();
                if (selectedCrosshair.get() > 7){
                    selectedCrosshair.set(1);
                }

            }if (event.getCode() == KeyCode.DOWN) {
                selectedCrosshair.getAndDecrement();
                if (selectedCrosshair.get() < 1){
                    selectedCrosshair.set(7);
                }

            }if (event.getCode() == KeyCode.ENTER){
                mediaPlayer.stop();
                duckImageView.setVisible(true);
                this.duckImageView.setImage(new Image("assets/duck_black/4.png"));
                //duckImageView.setScaleX();
                duckAnimation.setCycleCount(Timeline.INDEFINITE);
                duckAnimation.play();
                mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(INTRO_SOUND_PATH)).toString()));
                mediaPlayer.play();
                mediaPlayer.setOnEndOfMedia(() -> window.setScene(gameScene1));
            }

            selectionBackground.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/background/" + selectedBackground + ".png")).toExternalForm()));
            crosshairIcon.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/crosshair/" + selectedCrosshair + ".png")).toExternalForm()));
            gameBackground1.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/background/" + selectedBackground + ".png")).toExternalForm()));
            gameBackground2.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/background/" + selectedBackground + ".png")).toExternalForm()));
            gameBackground3.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/background/" + selectedBackground + ".png")).toExternalForm()));
            gameBackground4.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/background/" + selectedBackground + ".png")).toExternalForm()));
            gameBackground5.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/background/" + selectedBackground + ".png")).toExternalForm()));
            gameBackground6.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/background/" + selectedBackground + ".png")).toExternalForm()));
            gameForeground1.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/foreground/" + selectedBackground + ".png")).toExternalForm()));
            gameForeground2.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/foreground/" + selectedBackground + ".png")).toExternalForm()));
            gameForeground3.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/foreground/" + selectedBackground + ".png")).toExternalForm()));
            gameForeground4.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/foreground/" + selectedBackground + ".png")).toExternalForm()));
            gameForeground5.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/foreground/" + selectedBackground + ".png")).toExternalForm()));
            gameForeground6.setImage(new Image(Objects.requireNonNull(getClass().getResource("assets/foreground/" + selectedBackground + ".png")).toExternalForm()));


            Cursor customCursor = new ImageCursor(crosshairIcon.getImage());
            gameScene1.setCursor(customCursor);
            gameScene2.setCursor(customCursor);
            gameScene3.setCursor(customCursor);
            gameScene4.setCursor(customCursor);
            gameScene5.setCursor(customCursor);
            gameScene6.setCursor(customCursor);
            backgroundSelectionScene.setCursor(Cursor.DEFAULT);
            titleScene.setCursor(Cursor.DEFAULT);
        });

        gamePane1.getChildren().addAll(gameBackground1, duckImageView, gameForeground1, createGameTexts(1));
        gamePane2.getChildren().addAll(gameBackground2, duckImageViewLevel2, gameForeground2, createGameTexts(2));
        gamePane3.getChildren().addAll(gameBackground3, duck1ImageViewLevel3, duck2ImageViewLevel3, gameForeground3, createGameTexts(3));
        gamePane4.getChildren().addAll(gameBackground4, duck1ImageViewLevel4, duck2ImageViewLevel4, gameForeground4, createGameTexts(4));
        gamePane5.getChildren().addAll(gameBackground5, duck1ImageViewLevel5, duck2ImageViewLevel5,duck3ImageViewLevel5,  gameForeground5, createGameTexts(5));
        gamePane6.getChildren().addAll(gameBackground6, duck1ImageViewLevel6, duck2ImageViewLevel6,duck3ImageViewLevel6,duck4ImageViewLevel6,  gameForeground6, createGameTexts(6));

        /**
         * Initializes and configures the duck animations and image views.
         * Creates a list of duck images, sets the initial image, size, and ID for the duck image view.
         * Defines the animation timeline for the duck movement and image changes.
         * Tracks the current image index and duck's X position.
         */

        List<Image> duckImages = new ArrayList<>();
        duckImages.add(new Image("assets/duck_black/4.png"));
        duckImages.add(new Image("assets/duck_black/5.png"));
        duckImages.add(new Image("assets/duck_black/6.png"));


        duckImageView.setImage(duckImages.get(0));
        duckImageView.setFitWidth(duckImageView.getImage().getWidth() * SCALE);
        duckImageView.setFitHeight(duckImageView.getImage().getHeight() * SCALE);
        duckImageView.setId("duckImageView");

        final int[] currentImageIndex = {0};
        final double[] duckX = {-((WINDOW_WIDTH-duckImageView.getImage().getWidth())/2 *SCALE)};

        duckAnimation = new Timeline(
                new KeyFrame(Duration.millis(300), event -> {
                    currentImageIndex[0] = (currentImageIndex[0] + 1) % duckImages.size();
                    duckImageView.setImage(duckImages.get(currentImageIndex[0]));

                    if (duckX[0] > ((WINDOW_WIDTH-duckImageView.getImage().getWidth())/2 *SCALE)){
                        isRightEdge1.set(true);
                        duckX[0] = ((WINDOW_WIDTH-duckImageView.getImage().getWidth())/2 *SCALE);
                    }
                    if (duckX[0] < -((WINDOW_WIDTH-duckImageView.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge1.set(false);
                        duckX[0] = -((WINDOW_WIDTH-duckImageView.getImage().getWidth())/2 *SCALE);
                    }
                    if (isRightEdge1.get()){
                        isGoingRight1.set(false);
                        duckImageView.setScaleX(-1);
                        duckX[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight1.set(true);
                        duckImageView.setScaleX(1);
                        duckX[0] += 15 * SCALE;
                    }
                    duckImageView.setTranslateX(duckX[0]);
                    duckImageView.setTranslateY(-80*SCALE);

                })
        );

        List<Image> duckImagesLevel2 = new ArrayList<>();
        duckImagesLevel2.add(new Image("assets/duck_blue/1.png"));
        duckImagesLevel2.add(new Image("assets/duck_blue/2.png"));
        duckImagesLevel2.add(new Image("assets/duck_blue/3.png"));

        duckImageViewLevel2.setImage(duckImagesLevel2.get(0));
        duckImageViewLevel2.setFitWidth(duckImageViewLevel2.getImage().getWidth() * SCALE);
        duckImageViewLevel2.setFitHeight(duckImageViewLevel2.getImage().getHeight() * SCALE);
        duckImageViewLevel2.setId("duckImageViewLevel2");

        final int[] currentImageIndexLevel2 = {0};
        final double[] duckXLevel2 = {0};
        final double[] duckYLevel2 = {0};

        duckAnimationLevel2 = new Timeline(

                new KeyFrame(Duration.millis(300), event -> {

                    // Resmi değiştir
                    currentImageIndexLevel2[0] = (currentImageIndexLevel2[0] + 1) % duckImagesLevel2.size();
                    duckImageViewLevel2.setImage(duckImagesLevel2.get(currentImageIndexLevel2[0]));

                    if (duckXLevel2[0] > ((WINDOW_WIDTH-duckImageViewLevel2.getImage().getWidth())/2 *SCALE)){
                        duckXLevel2[0] = ((WINDOW_WIDTH-duckImageViewLevel2.getImage().getWidth())/2 *SCALE);
                        isRightEdge1.set(true);
                    }
                    if (duckXLevel2[0] < -((WINDOW_WIDTH-duckImageViewLevel2.getImage().getWidth())/2 *SCALE)) {
                        duckXLevel2[0] = -((WINDOW_WIDTH-duckImageViewLevel2.getImage().getWidth())/2 *SCALE);
                        isRightEdge1.set(false);
                    }
                    if (duckYLevel2[0] > ((WINDOW_HEIGHT-duckImageViewLevel2.getImage().getHeight())/2 *SCALE)){
                        duckYLevel2[0] = ((WINDOW_HEIGHT-duckImageViewLevel2.getImage().getHeight())/2 *SCALE);
                        isDownEdge1.set(true);
                    }
                    if (duckYLevel2[0] < -((WINDOW_HEIGHT-duckImageViewLevel2.getImage().getHeight())/2 *SCALE)) {
                        isDownEdge1.set(false);
                        duckYLevel2[0] = -((WINDOW_HEIGHT-duckImageViewLevel2.getImage().getHeight())/2 *SCALE);
                    }
                    if (isRightEdge1.get()){
                        isGoingRight1.set(false);
                        duckImageViewLevel2.setScaleX(-1);
                        duckXLevel2[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight1.set(true);
                        duckImageViewLevel2.setScaleX(1);
                        duckXLevel2[0] += 15 * SCALE;
                    }
                    if (isDownEdge1.get()){
                        isGoingDown1.set(false);
                        duckImageViewLevel2.setScaleY(1);
                        duckYLevel2[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingDown1.set(true);
                        duckImageViewLevel2.setScaleY(-1);
                        duckYLevel2[0] += 15 * SCALE;
                    }
                    duckImageViewLevel2.setTranslateX(duckXLevel2[0]);
                    duckImageViewLevel2.setTranslateY(duckYLevel2[0]);


                })
        );

        List<Image> duck1ImagesLevel3 = new ArrayList<>();
        duck1ImagesLevel3.add(new Image("assets/duck_black/4.png"));
        duck1ImagesLevel3.add(new Image("assets/duck_black/5.png"));
        duck1ImagesLevel3.add(new Image("assets/duck_black/6.png"));

        duck1ImageViewLevel3.setImage(duck1ImagesLevel3.get(0));
        duck1ImageViewLevel3.setFitWidth(duck1ImageViewLevel3.getImage().getWidth() * SCALE);
        duck1ImageViewLevel3.setFitHeight(duck1ImageViewLevel3.getImage().getHeight() * SCALE);
        duck1ImageViewLevel3.setId("duck1ImageViewLevel3");

        final int[] currentImageIndex1Level3 = {0};
        final double[] duckX1Level3 = {-((WINDOW_WIDTH-duckImageView.getImage().getWidth())/2 *SCALE)};

        duck1AnimationLevel3 = new Timeline(
                new KeyFrame(Duration.millis(300), event -> {

                    currentImageIndex1Level3[0] = (currentImageIndex1Level3[0] + 1) % duck1ImagesLevel3.size();
                    duck1ImageViewLevel3.setImage(duck1ImagesLevel3.get(currentImageIndex1Level3[0]));

                    if (duckX1Level3[0] > ((WINDOW_WIDTH-duck1ImageViewLevel3.getImage().getWidth())/2 *SCALE)){
                        duckX1Level3[0] = ((WINDOW_WIDTH-duck1ImageViewLevel3.getImage().getWidth())/2 *SCALE);
                        isRightEdge1.set(true);
                    }
                    if (duckX1Level3[0] < -((WINDOW_WIDTH-duck1ImageViewLevel3.getImage().getWidth())/2 *SCALE)) {
                        duckX1Level3[0] = -((WINDOW_WIDTH-duck1ImageViewLevel3.getImage().getWidth())/2 *SCALE);
                        isRightEdge1.set(false);
                    }
                    if (isRightEdge1.get()){
                        isGoingRight1.set(false);
                        duck1ImageViewLevel3.setScaleX(-1);
                        duckX1Level3[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight1.set(true);
                        duck1ImageViewLevel3.setScaleX(1);
                        duckX1Level3[0] += 15 * SCALE;
                    }
                    duck1ImageViewLevel3.setTranslateX(duckX1Level3[0]);
                    duck1ImageViewLevel3.setTranslateY(-80*SCALE);

                })
        );

        List<Image> duck2ImagesLevel3 = new ArrayList<>();
        duck2ImagesLevel3.add(new Image("assets/duck_blue/4.png"));
        duck2ImagesLevel3.add(new Image("assets/duck_blue/5.png"));
        duck2ImagesLevel3.add(new Image("assets/duck_blue/6.png"));

        duck2ImageViewLevel3.setImage(duck2ImagesLevel3.get(0));
        duck2ImageViewLevel3.setFitWidth(duck2ImageViewLevel3.getImage().getWidth() * SCALE);
        duck2ImageViewLevel3.setFitHeight(duck2ImageViewLevel3.getImage().getHeight() * SCALE);
        duck2ImageViewLevel3.setId("duck2ImageViewLevel3");

        final int[] currentImageIndex2Level3 = {0};
        final double[] duckX2Level3 = {((WINDOW_WIDTH-duckImageView.getImage().getWidth())/2 *SCALE)};

        duck2AnimationLevel3 = new Timeline(
                new KeyFrame(Duration.millis(300), event -> {

                    currentImageIndex2Level3[0] = (currentImageIndex2Level3[0] + 1) % duck2ImagesLevel3.size();
                    duck2ImageViewLevel3.setImage(duck2ImagesLevel3.get(currentImageIndex2Level3[0]));

                    if (duckX2Level3[0] > ((WINDOW_WIDTH-duck2ImageViewLevel3.getImage().getWidth())/2 *SCALE)){
                        isRightEdge2.set(true);
                    }
                    if (duckX2Level3[0] < -((WINDOW_WIDTH-duck2ImageViewLevel3.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge2.set(false);
                    }
                    if (isRightEdge2.get()){
                        isGoingRight2.set(false);
                        duck2ImageViewLevel3.setScaleX(-1);
                        duckX2Level3[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight2.set(true);
                        duck2ImageViewLevel3.setScaleX(1);
                        duckX2Level3[0] += 15 * SCALE;
                    }
                    duck2ImageViewLevel3.setTranslateX(duckX2Level3[0]);
                    duck2ImageViewLevel3.setTranslateY(-10*SCALE);

                })
        );

        List<Image> duck1ImagesLevel4 = new ArrayList<>();
        duck1ImagesLevel4.add(new Image("assets/duck_black/1.png"));
        duck1ImagesLevel4.add(new Image("assets/duck_black/2.png"));
        duck1ImagesLevel4.add(new Image("assets/duck_black/3.png"));

        duck1ImageViewLevel4.setImage(duck1ImagesLevel4.get(0));
        duck1ImageViewLevel4.setFitWidth(duck1ImageViewLevel4.getImage().getWidth() * SCALE);
        duck1ImageViewLevel4.setFitHeight(duck1ImageViewLevel4.getImage().getHeight() * SCALE);
        duck1ImageViewLevel4.setId("duck1ImageViewLevel4");

        final int[] currentImageIndex1Level4 = {0};
        final double[] duckX1Level4 = {0};
        final double[] duckY1Level4 = {0};

        duck1AnimationLevel4 = new Timeline(

                new KeyFrame(Duration.millis(300), event -> {

                    currentImageIndex1Level4[0] = (currentImageIndex1Level4[0] + 1) % duck1ImagesLevel4.size();
                    duck1ImageViewLevel4.setImage(duck1ImagesLevel4.get(currentImageIndex1Level4[0]));

                    if (duckX1Level4[0] > ((WINDOW_WIDTH-duck1ImageViewLevel4.getImage().getWidth())/2 *SCALE)){
                        isRightEdge1.set(true);
                    }
                    if (duckX1Level4[0] < -((WINDOW_WIDTH-duck1ImageViewLevel4.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge1.set(false);
                    }
                    if (duckY1Level4[0] > ((WINDOW_HEIGHT-duck1ImageViewLevel4.getImage().getHeight())/2 *SCALE)){
                        isDownEdge1.set(true);
                    }
                    if (duckY1Level4[0] < -((WINDOW_HEIGHT-duck1ImageViewLevel4.getImage().getHeight())/2 *SCALE)) {
                        isDownEdge1.set(false);
                    }
                    if (isRightEdge1.get()){
                        isGoingRight1.set(false);
                        duck1ImageViewLevel4.setScaleX(-1);
                        duckX1Level4[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight1.set(true);
                        duck1ImageViewLevel4.setScaleX(1);
                        duckX1Level4[0] += 15 * SCALE;
                    }
                    if (isDownEdge1.get()){
                        isGoingDown1.set(false);
                        duck1ImageViewLevel4.setScaleY(1);
                        duckY1Level4[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingDown1.set(true);
                        duck1ImageViewLevel4.setScaleY(-1);
                        duckY1Level4[0] += 15 * SCALE;
                    }
                    duck1ImageViewLevel4.setTranslateX(duckX1Level4[0]);
                    duck1ImageViewLevel4.setTranslateY(duckY1Level4[0]);


                })
        );

        List<Image> duck2ImagesLevel4 = new ArrayList<>();
        duck2ImagesLevel4.add(new Image("assets/duck_blue/1.png"));
        duck2ImagesLevel4.add(new Image("assets/duck_blue/2.png"));
        duck2ImagesLevel4.add(new Image("assets/duck_blue/3.png"));

        duck2ImageViewLevel4.setImage(duck2ImagesLevel4.get(0));
        duck2ImageViewLevel4.setFitWidth(duck2ImageViewLevel4.getImage().getWidth() * SCALE);
        duck2ImageViewLevel4.setFitHeight(duck2ImageViewLevel4.getImage().getHeight() * SCALE);
        duck2ImageViewLevel4.setId("duck2ImageViewLevel4");

        final int[] currentImageIndex2Level4 = {0};
        final double[] duckX2Level4 = {-(duck2ImageViewLevel4.getImage().getWidth()/2 *SCALE)};
        final double[] duckY2Level4 = {-(duck2ImageViewLevel4.getImage().getHeight()) / 2 * SCALE};

        duck2AnimationLevel4 = new Timeline(

                new KeyFrame(Duration.millis(300), event -> {

                    currentImageIndex2Level4[0] = (currentImageIndex2Level4[0] + 1) % duck2ImagesLevel4.size();
                    duck2ImageViewLevel4.setImage(duck2ImagesLevel4.get(currentImageIndex2Level4[0]));

                    if (duckX2Level4[0] > ((WINDOW_WIDTH-duck2ImageViewLevel4.getImage().getWidth())/2 *SCALE)){
                        isRightEdge2.set(true);
                    }
                    if (duckX2Level4[0] < -((WINDOW_WIDTH-duck2ImageViewLevel4.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge2.set(false);
                    }
                    if (duckY2Level4[0] > ((WINDOW_HEIGHT-duck2ImageViewLevel4.getImage().getHeight())/2 *SCALE)){
                        isDownEdge2.set(true);
                    }
                    if (duckY2Level4[0] < -((WINDOW_HEIGHT-duck2ImageViewLevel4.getImage().getHeight())/2 *SCALE)) {
                        isDownEdge2.set(false);
                    }
                    if (isRightEdge2.get()){
                        isGoingRight2.set(false);
                        duck2ImageViewLevel4.setScaleX(-1);
                        duckX2Level4[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight2.set(true);
                        duck2ImageViewLevel4.setScaleX(1);
                        duckX2Level4[0] += 15 * SCALE;
                    }
                    if (isDownEdge2.get()){
                        isGoingDown2.set(false);
                        duck2ImageViewLevel4.setScaleY(1);
                        duckY2Level4[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingDown2.set(true);
                        duck2ImageViewLevel4.setScaleY(-1);
                        duckY2Level4[0] += 15 * SCALE;
                    }
                    duck2ImageViewLevel4.setTranslateX(duckX2Level4[0]);
                    duck2ImageViewLevel4.setTranslateY(duckY2Level4[0]);


                })
        );

        List<Image> duck1ImagesLevel5 = new ArrayList<>();
        duck1ImagesLevel5.add(new Image("assets/duck_black/4.png"));
        duck1ImagesLevel5.add(new Image("assets/duck_black/5.png"));
        duck1ImagesLevel5.add(new Image("assets/duck_black/6.png"));

        duck1ImageViewLevel5.setImage(duck1ImagesLevel5.get(0));
        duck1ImageViewLevel5.setFitWidth(duck1ImageViewLevel5.getImage().getWidth() * SCALE);
        duck1ImageViewLevel5.setFitHeight(duck1ImageViewLevel5.getImage().getHeight() * SCALE);
        duck1ImageViewLevel5.setId("duck1ImageViewLevel5");

        final int[] currentImageIndex1Level5 = {0};
        final double[] duckX1Level5 = {-(WINDOW_WIDTH-duck1ImageViewLevel5.getImage().getWidth())/2 *SCALE};

        duck1AnimationLevel5 = new Timeline(
                new KeyFrame(Duration.millis(300), event -> {

                    currentImageIndex1Level5[0] = (currentImageIndex1Level5[0] + 1) % duck1ImagesLevel5.size();
                    duck1ImageViewLevel5.setImage(duck1ImagesLevel5.get(currentImageIndex1Level5[0]));

                    if (duckX1Level5[0] > ((WINDOW_WIDTH-duck1ImageViewLevel5.getImage().getWidth())/2 *SCALE)){
                        isRightEdge1.set(true);
                    }
                    if (duckX1Level5[0] < -((WINDOW_WIDTH-duck1ImageViewLevel5.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge1.set(false);
                    }
                    if (isRightEdge1.get()){
                        isGoingRight1.set(false);
                        duck1ImageViewLevel5.setScaleX(-1);
                        duckX1Level5[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight1.set(true);
                        duck1ImageViewLevel5.setScaleX(1);
                        duckX1Level5[0] += 15 * SCALE;
                    }
                    duck1ImageViewLevel5.setTranslateX(duckX1Level5[0]);
                    duck1ImageViewLevel5.setTranslateY(-80*SCALE);

                })
        );

        List<Image> duck2ImagesLevel5 = new ArrayList<>();
        duck2ImagesLevel5.add(new Image("assets/duck_blue/4.png"));
        duck2ImagesLevel5.add(new Image("assets/duck_blue/5.png"));
        duck2ImagesLevel5.add(new Image("assets/duck_blue/6.png"));

        duck2ImageViewLevel5.setImage(duck2ImagesLevel5.get(0));
        duck2ImageViewLevel5.setFitWidth(duck2ImageViewLevel5.getImage().getWidth() * SCALE);
        duck2ImageViewLevel5.setFitHeight(duck2ImageViewLevel5.getImage().getHeight() * SCALE);
        duck2ImageViewLevel5.setId("duck2ImageViewLevel5");

        final int[] currentImageIndex2Level5 = {0};
        final double[] duckX2Level5 = {((WINDOW_WIDTH-duck2ImageViewLevel5.getImage().getWidth())/2 *SCALE)};

        duck2AnimationLevel5 = new Timeline(
                new KeyFrame(Duration.millis(300), event -> {

                    currentImageIndex2Level5[0] = (currentImageIndex2Level5[0] + 1) % duck2ImagesLevel5.size();
                    duck2ImageViewLevel5.setImage(duck2ImagesLevel5.get(currentImageIndex2Level5[0]));

                    if (duckX2Level5[0] > ((WINDOW_WIDTH-duck2ImageViewLevel5.getImage().getWidth())/2 *SCALE)){
                        isRightEdge2.set(true);
                    }
                    if (duckX2Level5[0] < -((WINDOW_WIDTH-duck2ImageViewLevel5.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge2.set(false);
                    }
                    if (isRightEdge2.get()){
                        isGoingRight2.set(false);
                        duck2ImageViewLevel5.setScaleX(-1);
                        duckX2Level5[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight2.set(true);
                        duck2ImageViewLevel5.setScaleX(1);
                        duckX2Level5[0] += 15 * SCALE;
                    }
                    duck2ImageViewLevel5.setTranslateX(duckX2Level5[0]);
                    duck2ImageViewLevel5.setTranslateY(-10*SCALE);

                })
        );

        List<Image> duck3ImagesLevel5 = new ArrayList<>();
        duck3ImagesLevel5.add(new Image("assets/duck_red/1.png"));
        duck3ImagesLevel5.add(new Image("assets/duck_red/2.png"));
        duck3ImagesLevel5.add(new Image("assets/duck_red/3.png"));

        duck3ImageViewLevel5.setImage(duckImagesLevel2.get(0));
        duck3ImageViewLevel5.setFitWidth(duck3ImageViewLevel5.getImage().getWidth() * SCALE);
        duck3ImageViewLevel5.setFitHeight(duck3ImageViewLevel5.getImage().getHeight() * SCALE);
        duck3ImageViewLevel5.setId("duck3ImageViewLevel5");

        final int[] currentImageIndex3Level5 = {0};
        final double[] duckX3Level5 = {-(duckImageViewLevel2.getImage().getWidth()/2 *SCALE)};
        final double[] duckY3Level5 = {-(duckImageViewLevel2.getImage().getHeight()) / 2 * SCALE};

        duck3AnimationLevel5 = new Timeline(

                new KeyFrame(Duration.millis(300), event -> {

                    // Resmi değiştir
                    currentImageIndex3Level5[0] = (currentImageIndex3Level5[0] + 1) % duck3ImagesLevel5.size();
                    duck3ImageViewLevel5.setImage(duck3ImagesLevel5.get(currentImageIndex3Level5[0]));

                    // Hareket kodu buraya gelecek
                    if (duckX3Level5[0] > ((WINDOW_WIDTH-duck3ImageViewLevel5.getImage().getWidth())/2 *SCALE)){
                        isRightEdge3.set(true);
                    }
                    if (duckX3Level5[0] < -((WINDOW_WIDTH-duck3ImageViewLevel5.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge3.set(false);
                    }
                    if (duckY3Level5[0] > ((WINDOW_HEIGHT-duck3ImageViewLevel5.getImage().getHeight())/2 *SCALE)){
                        isDownEdge3.set(true);
                    }
                    if (duckY3Level5[0] < -((WINDOW_HEIGHT-duck3ImageViewLevel5.getImage().getHeight())/2 *SCALE)) {
                        isDownEdge3.set(false);
                    }
                    if (isRightEdge3.get()){
                        isGoingRight3.set(false);
                        duck3ImageViewLevel5.setScaleX(-1);
                        duckX3Level5[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight3.set(true);
                        duck3ImageViewLevel5.setScaleX(1);
                        duckX3Level5[0] += 15 * SCALE;
                    }
                    if (isDownEdge3.get()){
                        isGoingDown3.set(false);
                        duck3ImageViewLevel5.setScaleY(1);
                        duckY3Level5[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingDown3.set(true);
                        duck3ImageViewLevel5.setScaleY(-1);
                        duckY3Level5[0] += 15 * SCALE;
                    }
                    duck3ImageViewLevel5.setTranslateX(duckX3Level5[0]);
                    duck3ImageViewLevel5.setTranslateY(duckY3Level5[0]);


                })
        );

        List<Image> duck1ImagesLevel6 = new ArrayList<>();
        duck1ImagesLevel6.add(new Image("assets/duck_black/4.png"));
        duck1ImagesLevel6.add(new Image("assets/duck_black/5.png"));
        duck1ImagesLevel6.add(new Image("assets/duck_black/6.png"));

        duck1ImageViewLevel6.setImage(duck1ImagesLevel6.get(0));
        duck1ImageViewLevel6.setFitWidth(duck1ImageViewLevel6.getImage().getWidth() * SCALE);
        duck1ImageViewLevel6.setFitHeight(duck1ImageViewLevel6.getImage().getHeight() * SCALE);
        duck1ImageViewLevel6.setId("duck1ImageViewLevel6");

        final int[] currentImageIndex1Level6 = {0};
        final double[] duckX1Level6 = {-(WINDOW_WIDTH-duck1ImageViewLevel6.getImage().getWidth())/2 *SCALE};

        duck1AnimationLevel6 = new Timeline(
                new KeyFrame(Duration.millis(300), event -> {
                    currentImageIndex1Level6[0] = (currentImageIndex1Level6[0] + 1) % duck1ImagesLevel6.size();
                    duck1ImageViewLevel6.setImage(duck1ImagesLevel6.get(currentImageIndex1Level6[0]));

                    if (duckX1Level6[0] > ((WINDOW_WIDTH-duck1ImageViewLevel6.getImage().getWidth())/2 *SCALE)){
                        isRightEdge1.set(true);
                    }
                    if (duckX1Level6[0] < -((WINDOW_WIDTH-duck1ImageViewLevel6.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge1.set(false);
                    }
                    if (isRightEdge1.get()){
                        isGoingRight1.set(false);
                        duck1ImageViewLevel6.setScaleX(-1);
                        duckX1Level6[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight1.set(true);
                        duck1ImageViewLevel6.setScaleX(1);
                        duckX1Level6[0] += 15 * SCALE;
                    }
                    duck1ImageViewLevel6.setTranslateX(duckX1Level6[0]);
                    duck1ImageViewLevel6.setTranslateY(-80*SCALE);

                })
        );

        List<Image> duck2ImagesLevel6 = new ArrayList<>();
        duck2ImagesLevel6.add(new Image("assets/duck_blue/4.png"));
        duck2ImagesLevel6.add(new Image("assets/duck_blue/5.png"));
        duck2ImagesLevel6.add(new Image("assets/duck_blue/6.png"));

        duck2ImageViewLevel6.setImage(duck2ImagesLevel5.get(0));
        duck2ImageViewLevel6.setFitWidth(duck2ImageViewLevel6.getImage().getWidth() * SCALE);
        duck2ImageViewLevel6.setFitHeight(duck2ImageViewLevel6.getImage().getHeight() * SCALE);
        duck2ImageViewLevel6.setId("duck2ImageViewLevel6");

        final int[] currentImageIndex2Level6 = {0};
        final double[] duckX2Level6 = {(WINDOW_WIDTH-duck1ImageViewLevel6.getImage().getWidth())/2 *SCALE};

        duck2AnimationLevel6 = new Timeline(
                new KeyFrame(Duration.millis(300), event -> {

                    currentImageIndex2Level6[0] = (currentImageIndex2Level6[0] + 1) % duck2ImagesLevel6.size();
                    duck2ImageViewLevel6.setImage(duck2ImagesLevel6.get(currentImageIndex2Level6[0]));

                    if (duckX2Level6[0] > ((WINDOW_WIDTH-duck2ImageViewLevel6.getImage().getWidth())/2 *SCALE)){
                        isRightEdge2.set(true);
                    }
                    if (duckX2Level6[0] < -((WINDOW_WIDTH-duck2ImageViewLevel6.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge2.set(false);
                    }
                    if (isRightEdge2.get()){
                        isGoingRight2.set(false);
                        duck2ImageViewLevel6.setScaleX(-1);
                        duckX2Level6[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight2.set(true);
                        duck2ImageViewLevel6.setScaleX(1);
                        duckX2Level6[0] += 15 * SCALE;
                    }
                    duck2ImageViewLevel6.setTranslateX(duckX2Level6[0]);
                    duck2ImageViewLevel6.setTranslateY(-10*SCALE);

                })
        );

        List<Image> duck3ImagesLevel6 = new ArrayList<>();
        duck3ImagesLevel6.add(new Image("assets/duck_red/1.png"));
        duck3ImagesLevel6.add(new Image("assets/duck_red/2.png"));
        duck3ImagesLevel6.add(new Image("assets/duck_red/3.png"));

        duck3ImageViewLevel6.setImage(duck1ImagesLevel4.get(0));
        duck3ImageViewLevel6.setFitWidth(duck3ImageViewLevel6.getImage().getWidth() * SCALE);
        duck3ImageViewLevel6.setFitHeight(duck3ImageViewLevel6.getImage().getHeight() * SCALE);
        duck3ImageViewLevel6.setId("duck3ImageViewLevel6");

        final int[] currentImageIndex3Level6 = {0};
        final double[] duckX3Level6 = {-(duck3ImageViewLevel6.getImage().getWidth()/2 *SCALE)};
        final double[] duckY3Level6 = {-(duck3ImageViewLevel6.getImage().getHeight()) / 2 * SCALE};


        duck3AnimationLevel6 = new Timeline(

                new KeyFrame(Duration.millis(300), event -> {

                    // Resmi değiştir
                    currentImageIndex3Level6[0] = (currentImageIndex3Level6[0] + 1) % duck3ImagesLevel6.size();
                    duck3ImageViewLevel6.setImage(duck3ImagesLevel6.get(currentImageIndex3Level6[0]));

                    // Hareket kodu buraya gelecek
                    if (duckX3Level6[0] > ((WINDOW_WIDTH-duck3ImageViewLevel6.getImage().getWidth())/2 *SCALE)){
                        isRightEdge3.set(true);
                    }
                    if (duckX3Level6[0] < -((WINDOW_WIDTH-duck3ImageViewLevel6.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge3.set(false);
                    }
                    if (duckY3Level6[0] > ((WINDOW_HEIGHT-duck3ImageViewLevel6.getImage().getHeight())/2 *SCALE)){
                        isDownEdge3.set(true);
                    }
                    if (duckY3Level6[0] < -((WINDOW_HEIGHT-duck3ImageViewLevel6.getImage().getHeight())/2 *SCALE)) {
                        isDownEdge3.set(false);
                    }
                    if (isRightEdge3.get()){
                        isGoingRight3.set(false);
                        duck3ImageViewLevel6.setScaleX(-1);
                        duckX3Level6[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight3.set(true);
                        duck3ImageViewLevel6.setScaleX(1);
                        duckX3Level6[0] += 15 * SCALE;
                    }
                    if (isDownEdge3.get()){
                        isGoingDown3.set(false);
                        duck3ImageViewLevel6.setScaleY(1);
                        duckY3Level6[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingDown3.set(true);
                        duck3ImageViewLevel6.setScaleY(-1);
                        duckY3Level6[0] += 15 * SCALE;
                    }
                    duck3ImageViewLevel6.setTranslateX(duckX3Level6[0]);
                    duck3ImageViewLevel6.setTranslateY(duckY3Level6[0]);


                })
        );

        List<Image> duck4ImagesLevel6 = new ArrayList<>();
        duck4ImagesLevel6.add(new Image("assets/duck_blue/1.png"));
        duck4ImagesLevel6.add(new Image("assets/duck_blue/2.png"));
        duck4ImagesLevel6.add(new Image("assets/duck_blue/3.png"));

        duck4ImageViewLevel6.setImage(duck2ImagesLevel4.get(0));
        duck4ImageViewLevel6.setFitWidth(duck4ImageViewLevel6.getImage().getWidth() * SCALE);
        duck4ImageViewLevel6.setFitHeight(duck4ImageViewLevel6.getImage().getHeight() * SCALE);
        duck4ImageViewLevel6.setId("duck4ImageViewLevel6");

        final int[] currentImageIndex4Level6 = {0};
        final double[] duckX4Level6 = {-(duck4ImageViewLevel6.getImage().getWidth()/2 *SCALE)};
        final double[] duckY4Level6 = {-(duck4ImageViewLevel6.getImage().getHeight()) / 2 * SCALE};


        duck4AnimationLevel6 = new Timeline(

                new KeyFrame(Duration.millis(300), event -> {

                    currentImageIndex4Level6[0] = (currentImageIndex4Level6[0] + 1) % duck4ImagesLevel6.size();
                    duck4ImageViewLevel6.setImage(duck4ImagesLevel6.get(currentImageIndex4Level6[0]));

                    if (duckX4Level6[0] > ((WINDOW_WIDTH-duck4ImageViewLevel6.getImage().getWidth())/2 *SCALE)){
                        isRightEdge4.set(true);
                    }
                    if (duckX4Level6[0] < -((WINDOW_WIDTH-duck4ImageViewLevel6.getImage().getWidth())/2 *SCALE)) {
                        isRightEdge4.set(false);
                    }
                    if (duckY4Level6[0] > ((WINDOW_HEIGHT-duck4ImageViewLevel6.getImage().getHeight())/2 *SCALE)){
                        isDownEdge4.set(true);
                    }
                    if (duckY4Level6[0] < -((WINDOW_HEIGHT-duck4ImageViewLevel6.getImage().getHeight())/2 *SCALE)) {
                        isDownEdge4.set(false);
                    }
                    if (isRightEdge4.get()){
                        isGoingRight4.set(false);
                        duck4ImageViewLevel6.setScaleX(-1);
                        duckX4Level6[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingRight4.set(true);
                        duck4ImageViewLevel6.setScaleX(1);
                        duckX4Level6[0] += 15 * SCALE;
                    }
                    if (isDownEdge4.get()){
                        isGoingDown4.set(false);
                        duck4ImageViewLevel6.setScaleY(1);
                        duckY4Level6[0] -= 15 * SCALE;
                    }
                    else {
                        isGoingDown4.set(true);
                        duck4ImageViewLevel6.setScaleY(-1);
                        duckY4Level6[0] += 15 * SCALE;
                    }
                    duck4ImageViewLevel6.setTranslateX(duckX4Level6[0]);
                    duck4ImageViewLevel6.setTranslateY(duckY4Level6[0]);


                })
        );

        /**
         * Sets the mouse click event handlers for each game scene.
         * Handles the logic when the mouse is clicked within the game scene.
         * Checks if there is ammo left and ducks remaining.
         * Plays gunshot sound and checks if the clicked position overlaps with a duck image.
         * Updates the game state based on the click result (hit or miss).
         * Handles level completion and transition to the next level.
         * Handles game over condition and allows restarting or returning to the title scene.
         *
         * @param event The mouse click event object
         */

        gameScene1.setOnMouseClicked(event -> {
            if(ammoLeftLevel1 > 0 && duckLeftLevel1 > 0) {
                double mouseX = event.getX();
                double mouseY = event.getY();
                isImageClicked(mouseX, mouseY, duckImageView);
                mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GUNSHOT_SOUND_PATH)).toString()));
                mediaPlayer.play();
                if (isImageClicked(mouseX, mouseY, duckImageView)) {
                    killDuck(duckImageView, duckAnimation, gamePane1);
                    duckImageView.setImage(null);
                    duckLeftLevel1 -= 1;
                    if (duckLeftLevel1 == 0) {
                        gamePane1.getChildren().remove(ammoTextLevel1);
                        ammoLeftLevel1= 3;
                        duckLeftLevel1 = 1;
                        gamePane1.getChildren().add(levelCompletedText1);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        gameScene1.setOnKeyPressed(eventLevel1 -> {
                            if (eventLevel1.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane2.getChildren().add(ammoTextLevel2);
                                isGoingRight1.set(true);
                                isRightEdge1.set(false);
                                window.setScene(gameScene2);
                                gamePane1.getChildren().remove(levelCompletedText1);
                                duckImageViewLevel2.setVisible(true);
                                duckImageViewLevel2.setImage(new Image("assets/duck_blue/4.png"));
                                isRightEdge1.set(false);
                                isGoingRight1.set(true);
                                duckImageViewLevel2.setVisible(true);
                                duckAnimationLevel2.setCycleCount(Timeline.INDEFINITE);
                                duckAnimationLevel2.play();

                            }
                        });

                    }
                }
                ammoLeftLevel1 -= 1;
                ammoTextLevel1.setText("Ammo Left: " + ammoLeftLevel1);
                if (ammoLeftLevel1 == 0 && duckLeftLevel1 > 0) {

                    gameScene1.setOnKeyPressed(eventLevel1 -> {
                        if (eventLevel1.getCode() == KeyCode.ESCAPE) {
                            mediaPlayer.stop();
                            window.setScene(titleScene);
                            gamePane1.getChildren().remove(textsGameOver);
                            gamePane1.getChildren().remove(ammoTextLevel1);
                            ammoLeftLevel1 = 3;
                            ammoTextLevel1.setText("Ammo Left: " + ammoLeftLevel1);
                        }
                        if (eventLevel1.getCode() == KeyCode.ENTER) {
                            mediaPlayer.stop();
                            window.setScene(gameScene1);
                            gamePane1.getChildren().remove(textsGameOver);
                            gamePane1.getChildren().remove(ammoTextLevel1);
                            ammoLeftLevel1 = 3;
                            ammoTextLevel1.setText("Ammo Left: " + ammoLeftLevel1);
                            duckImageView.setVisible(true);
                            duckAnimation.play();
                            duckImageView.setImage(new Image("assets/duck_black/4.png"));
                        }
                    });
                    handleGameOver(1);
                }
            }


        });

        /**
         * Handles the mouse click event on gameScene2.
         *
         * @param event The MouseEvent triggered by the click.
         */
        gameScene2.setOnMouseClicked(event -> {

            if(ammoLeftLevel2 > 0 && duckLeftLevel2 > 0) {
                double mouseX = event.getX();
                double mouseY = event.getY();
                mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GUNSHOT_SOUND_PATH)).toString()));
                mediaPlayer.play();


                if (isImageClicked(mouseX, mouseY, duckImageViewLevel2)) {
                    killDuck(duckImageViewLevel2, duckAnimationLevel2, gamePane2);
                    duckImageViewLevel2.setImage(null);
                    duckLeftLevel2 -= 1;
                    if (duckLeftLevel2 == 0) {
                        gamePane2.getChildren().remove(ammoTextLevel2);
                        ammoLeftLevel2= 3;
                        duckLeftLevel2 = 1;
                        gamePane2.getChildren().add(levelCompletedText2);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        ammoTextLevel3.setText("Ammo Left: " + ammoLeftLevel3);
                        gameScene2.setOnKeyPressed(eventLevel2 -> {
                            if (eventLevel2.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane3.getChildren().add(ammoTextLevel3);
                                isRightEdge1.set(false);
                                isRightEdge2.set(true);
                                isGoingRight1.set(true);
                                window.setScene(gameScene3);
                                duck1ImageViewLevel3.setVisible(true);
                                duck1ImageViewLevel3.setImage(new Image("assets/duck_black/4.png"));
                                duck2ImageViewLevel3.setVisible(true);
                                duck2ImageViewLevel3.setImage(new Image("assets/duck_blue/4.png"));
                                gamePane2.getChildren().remove(levelCompletedText2);
                                duck1AnimationLevel3.setCycleCount(Timeline.INDEFINITE);
                                duck2AnimationLevel3.setCycleCount(Timeline.INDEFINITE);
                                duck1AnimationLevel3.play();
                                duck2AnimationLevel3.play();

                            }
                        });

                    }
                }
                ammoLeftLevel2 -= 1;
                ammoTextLevel2.setText("Ammo Left: " + ammoLeftLevel2);
                if (ammoLeftLevel2 == 0 && duckLeftLevel2 > 0) {

                    gameScene2.setOnKeyPressed(eventLevel2 -> {
                        if (eventLevel2.getCode() == KeyCode.ESCAPE) {
                            mediaPlayer.stop();
                            window.setScene(titleScene);
                            gamePane2.getChildren().remove(textsGameOver);
                            gamePane2.getChildren().remove(ammoTextLevel2);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoTextLevel1.setText("Ammo Left: " + ammoLeftLevel1);
                            ammoTextLevel2.setText("Ammo Left: " + ammoLeftLevel2);

                        }
                        if (eventLevel2.getCode() == KeyCode.ENTER) {
                            mediaPlayer.stop();
                            window.setScene(gameScene1);
                            gamePane2.getChildren().remove(textsGameOver);
                            gamePane2.getChildren().remove(ammoTextLevel2);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoTextLevel2.setText("Ammo Left: " + ammoLeftLevel2);
                            duckImageView.setVisible(true);
                            duckAnimation.play();
                            duckImageView.setImage(new Image("assets/duck_black/4.png"));

                        }
                    });
                    handleGameOver(2);
                }
            }


        });

        /**
         * Handles the mouse click event on gameScene3.
         *
         * @param event The MouseEvent triggered by the click.
         */
        gameScene3.setOnMouseClicked(event -> {

            if(ammoLeftLevel3 > 0 && duckLeftLevel3 > 0) {
                double mouseX = event.getX();
                double mouseY = event.getY();
                mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GUNSHOT_SOUND_PATH)).toString()));
                mediaPlayer.play();


                if (isImageClicked(mouseX, mouseY, duck1ImageViewLevel3)) {
                    killDuck(duck1ImageViewLevel3, duck1AnimationLevel3, gamePane3);
                    duck1ImageViewLevel3.setImage(null);
                    duckLeftLevel3 -= 1;
                    if (duckLeftLevel3 == 0) {
                        gamePane3.getChildren().remove(ammoTextLevel3);
                        ammoLeftLevel3= 6;
                        duckLeftLevel3 = 2;
                        gamePane3.getChildren().add(levelCompletedText3);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        ammoTextLevel4.setText("Ammo Left: " + ammoLeftLevel4);
                        gameScene3.setOnKeyPressed(eventLevel3 -> {
                            if (eventLevel3.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane4.getChildren().remove(ammoTextLevel4);
                                gamePane4.getChildren().add(ammoTextLevel4);
                                isRightEdge1.set(false);
                                isRightEdge2.set(true);
                                isGoingRight2.set(true);
                                isGoingRight1.set(false);
                                isDownEdge1.set(true);
                                isDownEdge2.set(true);
                                window.setScene(gameScene4);
                                gamePane3.getChildren().remove(levelCompletedText3);
                                duck1ImageViewLevel4.setVisible(true);
                                duck1ImageViewLevel4.setImage(new Image("assets/duck_black/4.png"));
                                duck2ImageViewLevel4.setVisible(true);
                                duck2ImageViewLevel4.setImage(new Image("assets/duck_blue/4.png"));
                                duck1AnimationLevel4.setCycleCount(Timeline.INDEFINITE);
                                duck2AnimationLevel4.setCycleCount(Timeline.INDEFINITE);
                                duck1AnimationLevel4.play();
                                duck2AnimationLevel4.play();


                            }
                        });

                    }
                }
                if (isImageClicked(mouseX, mouseY, duck2ImageViewLevel3)){
                    killDuck(duck2ImageViewLevel3, duck2AnimationLevel3, gamePane3);
                    duck2ImageViewLevel3.setImage(null);
                    duckLeftLevel3 -= 1;
                    if (duckLeftLevel3 == 0) {
                        gamePane3.getChildren().remove(ammoTextLevel3);
                        ammoLeftLevel3= 6;
                        duckLeftLevel3 = 2;
                        gamePane3.getChildren().add(levelCompletedText3);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        ammoTextLevel4.setText("Ammo Left: " + ammoLeftLevel4);
                        gameScene3.setOnKeyPressed(eventLevel3 -> {
                            if (eventLevel3.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane4.getChildren().remove(ammoTextLevel4);
                                gamePane4.getChildren().add(ammoTextLevel4);
                                isRightEdge1.set(false);
                                isRightEdge2.set(true);
                                isGoingRight2.set(true);
                                isGoingRight1.set(false);
                                isDownEdge1.set(true);
                                isDownEdge2.set(true);
                                window.setScene(gameScene4);
                                gamePane3.getChildren().remove(levelCompletedText3);
                                duck1ImageViewLevel4.setVisible(true);
                                duck1ImageViewLevel4.setImage(new Image("assets/duck_black/4.png"));
                                duck2ImageViewLevel4.setVisible(true);
                                duck2ImageViewLevel4.setImage(new Image("assets/duck_blue/4.png"));
                                duck1AnimationLevel4.setCycleCount(Timeline.INDEFINITE);
                                duck2AnimationLevel4.setCycleCount(Timeline.INDEFINITE);
                                duck1AnimationLevel4.play();
                                duck2AnimationLevel4.play();

                            }
                        });

                    }

                }
                ammoLeftLevel3 -= 1;
                ammoTextLevel3.setText("Ammo Left: " + ammoLeftLevel3);
                if (ammoLeftLevel3 == 0 && duckLeftLevel3 > 0) {

                    gameScene3.setOnKeyPressed(eventLevel3 -> {
                        if (eventLevel3.getCode() == KeyCode.ESCAPE) {
                            mediaPlayer.stop();
                            window.setScene(titleScene);
                            gamePane3.getChildren().remove(textsGameOver);
                            gamePane3.getChildren().remove(ammoTextLevel3);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoLeftLevel3 = 6;
                            ammoTextLevel1.setText("Ammo Left: " + ammoLeftLevel1);
                            ammoTextLevel2.setText("Ammo Left: " + ammoLeftLevel2);
                            ammoTextLevel3.setText("Ammo Left: " + ammoLeftLevel3);
                        }
                        if (eventLevel3.getCode() == KeyCode.ENTER) {
                            mediaPlayer.stop();
                            window.setScene(gameScene1);
                            gamePane3.getChildren().remove(textsGameOver);
                            gamePane3.getChildren().remove(ammoTextLevel3);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoLeftLevel3 = 6;
                            ammoTextLevel3.setText("Ammo Left: " + ammoLeftLevel3);
                            duckImageView.setVisible(true);
                            duckAnimation.play();
                            duckImageView.setImage(new Image("assets/duck_black/4.png"));
                        }
                    });
                    handleGameOver(3);
                }
            }


        });

        /**
         * Handles the mouse click event on gameScene4.
         *
         * @param event The MouseEvent triggered by the click.
         */
        gameScene4.setOnMouseClicked(event -> {

            if(ammoLeftLevel4 > 0 && duckLeftLevel4 > 0) {
                double mouseX = event.getX();
                double mouseY = event.getY();
                mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GUNSHOT_SOUND_PATH)).toString()));
                mediaPlayer.play();


                if (isImageClicked(mouseX, mouseY, duck1ImageViewLevel4)) {
                    killDuck(duck1ImageViewLevel4, duck1AnimationLevel4, gamePane4);
                    duck1ImageViewLevel4.setImage(null);
                    duckLeftLevel4 -= 1;
                    if (duckLeftLevel4 == 0) {
                        gamePane4.getChildren().remove(ammoTextLevel4);
                        ammoLeftLevel4= 6;
                        duckLeftLevel4 = 2;
                        gamePane4.getChildren().add(levelCompletedText4);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        ammoTextLevel5.setText("Ammo Left: " + ammoLeftLevel5);
                        gameScene4.setOnKeyPressed(eventLevel4 -> {
                            if (eventLevel4.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane5.getChildren().remove(ammoTextLevel5);
                                gamePane5.getChildren().add(ammoTextLevel5);
                                isRightEdge1.set(false);
                                isRightEdge2.set(true);
                                window.setScene(gameScene5);
                                gamePane4.getChildren().remove(levelCompletedText4);
                                duck1ImageViewLevel5.setVisible(true);
                                duck1ImageViewLevel5.setImage(new Image("assets/duck_black/4.png"));
                                duck2ImageViewLevel5.setVisible(true);
                                duck2ImageViewLevel5.setImage(new Image("assets/duck_blue/4.png"));
                                duck3ImageViewLevel5.setVisible(true);
                                duck3ImageViewLevel5.setImage(new Image("assets/duck_red/4.png"));
                                duck1AnimationLevel5.setCycleCount(Timeline.INDEFINITE);
                                duck2AnimationLevel5.setCycleCount(Timeline.INDEFINITE);
                                duck3AnimationLevel5.setCycleCount(Timeline.INDEFINITE);
                                duck1AnimationLevel5.play();
                                duck2AnimationLevel5.play();
                                duck3AnimationLevel5.play();

                            }
                        });

                    }
                }
                if (isImageClicked(mouseX, mouseY, duck2ImageViewLevel4)){
                    killDuck(duck2ImageViewLevel4, duck2AnimationLevel4, gamePane4);
                    duck2ImageViewLevel4.setImage(null);
                    duckLeftLevel4 -= 1;
                    if (duckLeftLevel4 == 0) {
                        gamePane4.getChildren().remove(ammoTextLevel4);
                        ammoLeftLevel4= 6;
                        duckLeftLevel4 = 2;
                        gamePane4.getChildren().add(levelCompletedText4);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        ammoTextLevel5.setText("Ammo Left: " + ammoLeftLevel5);
                        gameScene4.setOnKeyPressed(eventLevel4 -> {
                            if (eventLevel4.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane5.getChildren().remove(ammoTextLevel5);
                                gamePane5.getChildren().add(ammoTextLevel5);
                                isRightEdge1.set(false);
                                isRightEdge2.set(true);
                                window.setScene(gameScene5);
                                gamePane4.getChildren().remove(levelCompletedText4);
                                duck1ImageViewLevel5.setVisible(true);
                                duck1ImageViewLevel5.setImage(new Image("assets/duck_black/4.png"));
                                duck2ImageViewLevel5.setVisible(true);
                                duck2ImageViewLevel5.setImage(new Image("assets/duck_blue/4.png"));
                                duck3ImageViewLevel5.setVisible(true);
                                duck3ImageViewLevel5.setImage(new Image("assets/duck_red/4.png"));
                                duck1AnimationLevel5.setCycleCount(Timeline.INDEFINITE);
                                duck2AnimationLevel5.setCycleCount(Timeline.INDEFINITE);
                                duck3AnimationLevel5.setCycleCount(Timeline.INDEFINITE);
                                duck1AnimationLevel5.play();
                                duck2AnimationLevel5.play();
                                duck3AnimationLevel5.play();

                            }
                        });

                    }

                }
                ammoLeftLevel4 -= 1;
                ammoTextLevel4.setText("Ammo Left: " + ammoLeftLevel4);
                if (ammoLeftLevel4 == 0 && duckLeftLevel4 > 0) {

                    gameScene4.setOnKeyPressed(eventLevel4 -> {
                        if (eventLevel4.getCode() == KeyCode.ESCAPE) {
                            mediaPlayer.stop();
                            window.setScene(titleScene);
                            gamePane4.getChildren().remove(textsGameOver);
                            gamePane4.getChildren().remove(ammoTextLevel4);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoLeftLevel3 = 6;
                            ammoLeftLevel4 = 6;
                            ammoTextLevel1.setText("Ammo Left: " + ammoLeftLevel1);
                            ammoTextLevel2.setText("Ammo Left: " + ammoLeftLevel2);
                            ammoTextLevel3.setText("Ammo Left: " + ammoLeftLevel3);
                            ammoTextLevel4.setText("Ammo Left: " + ammoLeftLevel4);
                        }
                        if (eventLevel4.getCode() == KeyCode.ENTER) {
                            mediaPlayer.stop();
                            window.setScene(gameScene1);
                            gamePane4.getChildren().remove(textsGameOver);
                            gamePane4.getChildren().remove(ammoTextLevel4);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoLeftLevel3 = 6;
                            ammoLeftLevel4 = 6;
                            ammoTextLevel4.setText("Ammo Left: " + ammoLeftLevel4);
                            duckImageView.setVisible(true);
                            duckAnimation.play();
                            duckImageView.setImage(new Image("assets/duck_black/4.png"));
                        }
                    });
                    handleGameOver(4);
                }
            }
        });

        /**
         * Handles the mouse click event on gameScene5.
         *
         * @param event The MouseEvent triggered by the click.
         */
        gameScene5.setOnMouseClicked(event -> {

            if(ammoLeftLevel5 > 0 && duckLeftLevel5 > 0) {
                double mouseX = event.getX();
                double mouseY = event.getY();
                mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GUNSHOT_SOUND_PATH)).toString()));
                mediaPlayer.play();
                if (isImageClicked(mouseX, mouseY, duck1ImageViewLevel5)) {
                    killDuck(duck1ImageViewLevel5, duck1AnimationLevel5, gamePane5);
                    duck1ImageViewLevel5.setImage(null);
                    duckLeftLevel5 -= 1;
                    if (duckLeftLevel5 == 0) {
                        gamePane5.getChildren().remove(ammoTextLevel5);
                        ammoLeftLevel5= 9;
                        duckLeftLevel5 = 3;
                        gamePane5.getChildren().add(levelCompletedText5);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        ammoTextLevel6.setText("Ammo Left: " + ammoLeftLevel6);
                        gameScene5.setOnKeyPressed(eventLevel5 -> {
                            if (eventLevel5.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane6.getChildren().remove(ammoTextLevel6);
                                gamePane6.getChildren().add(ammoTextLevel6);
                                isRightEdge1.set(true);
                                isRightEdge2.set(false);
                                isRightEdge3.set(true);
                                isRightEdge4.set(false);
                                isDownEdge3.set(true);
                                isDownEdge4.set(true);
                                window.setScene(gameScene6);
                                gamePane5.getChildren().remove(levelCompletedText5);
                                duck1ImageViewLevel6.setVisible(true);
                                duck1ImageViewLevel6.setImage(new Image("assets/duck_black/4.png"));
                                duck2ImageViewLevel6.setVisible(true);
                                duck2ImageViewLevel6.setImage(new Image("assets/duck_blue/4.png"));
                                duck3ImageViewLevel6.setVisible(true);
                                duck3ImageViewLevel6.setImage(new Image("assets/duck_red/4.png"));
                                duck4ImageViewLevel6.setVisible(true);
                                duck4ImageViewLevel6.setImage(new Image("assets/duck_blue/4.png"));
                                duck1AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck2AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck3AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck4AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck1AnimationLevel6.play();
                                duck2AnimationLevel6.play();
                                duck3AnimationLevel6.play();
                                duck4AnimationLevel6.play();

                            }
                        });

                    }
                }
                if (isImageClicked(mouseX, mouseY, duck2ImageViewLevel5)){
                    killDuck(duck2ImageViewLevel5, duck2AnimationLevel5, gamePane5);
                    duck2ImageViewLevel5.setImage(null);
                    duckLeftLevel5 -= 1;
                    if (duckLeftLevel5 == 0) {
                        gamePane5.getChildren().remove(ammoTextLevel5);
                        ammoLeftLevel5= 9;
                        duckLeftLevel5 = 3;
                        gamePane5.getChildren().add(levelCompletedText5);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        ammoTextLevel6.setText("Ammo Left: " + ammoLeftLevel6);
                        gameScene5.setOnKeyPressed(eventLevel5 -> {
                            if (eventLevel5.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane5.getChildren().remove(ammoTextLevel5);
                                gamePane5.getChildren().add(ammoTextLevel5);
                                isRightEdge1.set(true);
                                isRightEdge2.set(false);
                                isRightEdge3.set(true);
                                isRightEdge4.set(false);
                                isDownEdge3.set(true);
                                isDownEdge4.set(true);
                                window.setScene(gameScene6);
                                gamePane5.getChildren().remove(levelCompletedText5);
                                duck1ImageViewLevel6.setVisible(true);
                                duck1ImageViewLevel6.setImage(new Image("assets/duck_black/4.png"));
                                duck2ImageViewLevel6.setVisible(true);
                                duck2ImageViewLevel6.setImage(new Image("assets/duck_blue/4.png"));
                                duck3ImageViewLevel6.setVisible(true);
                                duck3ImageViewLevel6.setImage(new Image("assets/duck_red/4.png"));
                                duck4ImageViewLevel6.setVisible(true);
                                duck4ImageViewLevel6.setImage(new Image("assets/duck_blue/4.png"));
                                duck1AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck2AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck3AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck4AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck1AnimationLevel6.play();
                                duck2AnimationLevel6.play();
                                duck3AnimationLevel6.play();
                                duck4AnimationLevel6.play();

                            }
                        });

                    }

                }
                if (isImageClicked(mouseX, mouseY, duck3ImageViewLevel5)) {
                    killDuck(duck3ImageViewLevel5, duck3AnimationLevel5, gamePane5);
                    duck3ImageViewLevel5.setImage(null);
                    duckLeftLevel5 -= 1;
                    if (duckLeftLevel5 == 0) {
                        gamePane5.getChildren().remove(ammoTextLevel5);
                        gamePane5.getChildren().remove(ammoLeftLevel1);
                        ammoLeftLevel5= 9;
                        duckLeftLevel5 = 3;
                        gamePane5.getChildren().add(levelCompletedText5);
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(LEVEL_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        ammoTextLevel6.setText("Ammo Left: " + ammoLeftLevel6);
                        gameScene5.setOnKeyPressed(eventLevel5 -> {
                            if (eventLevel5.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                gamePane5.getChildren().remove(ammoTextLevel5);
                                gamePane5.getChildren().add(ammoTextLevel5);
                                isRightEdge1.set(true);
                                isRightEdge2.set(false);
                                isRightEdge3.set(true);
                                isRightEdge4.set(false);
                                isDownEdge3.set(true);
                                isDownEdge4.set(true);
                                window.setScene(gameScene6);
                                gamePane5.getChildren().remove(levelCompletedText5);
                                duck1ImageViewLevel6.setVisible(true);
                                duck1ImageViewLevel6.setImage(new Image("assets/duck_black/4.png"));
                                duck2ImageViewLevel6.setVisible(true);
                                duck2ImageViewLevel6.setImage(new Image("assets/duck_blue/4.png"));
                                duck3ImageViewLevel6.setVisible(true);
                                duck3ImageViewLevel6.setImage(new Image("assets/duck_red/4.png"));
                                duck4ImageViewLevel6.setVisible(true);
                                duck4ImageViewLevel6.setImage(new Image("assets/duck_blue/4.png"));
                                duck1AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck2AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck3AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck4AnimationLevel6.setCycleCount(Timeline.INDEFINITE);
                                duck1AnimationLevel6.play();
                                duck2AnimationLevel6.play();
                                duck3AnimationLevel6.play();
                                duck4AnimationLevel6.play();

                            }
                        });

                    }
                }
                ammoLeftLevel5 -= 1;
                ammoTextLevel5.setText("Ammo Left: " + ammoLeftLevel5);
                if (ammoLeftLevel5 == 0 && duckLeftLevel5 > 0) {

                    gameScene5.setOnKeyPressed(eventLevel5 -> {
                        if (eventLevel5.getCode() == KeyCode.ESCAPE) {
                            window.setScene(titleScene);
                            gamePane5.getChildren().remove(textsGameOver);
                            gamePane5.getChildren().remove(ammoTextLevel5);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoLeftLevel3 = 6;
                            ammoLeftLevel4 = 6;
                            ammoLeftLevel5 = 9;
                            ammoTextLevel1.setText("Ammo Left: " + ammoLeftLevel1);
                            ammoTextLevel2.setText("Ammo Left: " + ammoLeftLevel2);
                            ammoTextLevel3.setText("Ammo Left: " + ammoLeftLevel3);
                            ammoTextLevel4.setText("Ammo Left: " + ammoLeftLevel4);
                            ammoTextLevel5.setText("Ammo Left: " + ammoLeftLevel5);
                        }
                        if (eventLevel5.getCode() == KeyCode.ENTER) {
                            mediaPlayer.stop();
                            window.setScene(gameScene1);
                            gamePane5.getChildren().remove(textsGameOver);
                            gamePane5.getChildren().remove(ammoTextLevel5);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoLeftLevel3 = 6;
                            ammoLeftLevel4 = 6;
                            ammoLeftLevel5 = 9;
                            ammoTextLevel5.setText("Ammo Left: " + ammoLeftLevel5);
                            duckImageView.setVisible(true);
                            duckAnimation.play();
                            duckImageView.setImage(new Image("assets/duck_black/4.png"));
                        }
                    });
                    handleGameOver(5);
                }
            }


        });

        /**
         * Handles the mouse click event on gameScene6.
         *
         * @param event The MouseEvent triggered by the click.
         */
        gameScene6.setOnMouseClicked(event -> {

            if(ammoLeftLevel6 > 0 && duckLeftLevel6 > 0) {
                double mouseX = event.getX();
                double mouseY = event.getY();
                mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GUNSHOT_SOUND_PATH)).toString()));
                mediaPlayer.play();
                if (isImageClicked(mouseX, mouseY, duck1ImageViewLevel6)) {
                    killDuck(duck1ImageViewLevel6, duck1AnimationLevel6, gamePane6);
                    duck1ImageViewLevel6.setImage(null);
                    duckLeftLevel6 -= 1;
                    if (duckLeftLevel6 == 0) {
                        gamePane6.getChildren().remove(ammoTextLevel6);
                        ammoLeftLevel6= 12;
                        duckLeftLevel6 = 4;
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GAME_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        Text LevelCompleted = CreateText.createText("You have completed the game!");
                        Text startText2 = CreateText.createBlinkingText("PRESS ENTER TO START");
                        Text exitTest2 = CreateText.createBlinkingText("PRESS ESC TO EXIT");
                        VBox texts2 = new VBox();
                        texts2.getChildren().addAll(LevelCompleted, startText2, exitTest2);
                        texts2.setAlignment(Pos.CENTER);
                        texts2.setTranslateY(-50 * SCALE);
                        gamePane6.getChildren().add(texts2);
                        texts2.setVisible(true);
                        gameScene6.setOnKeyPressed(eventLevel6 -> {
                            if (eventLevel6.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                window.setScene(gameScene1);
                                duckImageView.setImage(new Image("assets/duck_black/4.png"));
                                duckImageView.setVisible(true);
                                duckAnimation.play();
                                gamePane6.getChildren().remove(texts2);
                                ammoLeftLevel1 = 3;
                                ammoLeftLevel2= 3;
                                ammoLeftLevel3= 6;
                                ammoLeftLevel4= 6;
                                ammoLeftLevel5= 9;
                                ammoLeftLevel6= 12;
                            }else if(eventLevel6.getCode() == KeyCode.ESCAPE){
                                mediaPlayer.stop();
                                window.setScene(titleScene);
                                gamePane6.getChildren().remove(texts2);
                                ammoLeftLevel1 = 3;
                                ammoLeftLevel2= 3;
                                ammoLeftLevel3= 6;
                                ammoLeftLevel4= 6;
                                ammoLeftLevel5= 9;
                                ammoLeftLevel6= 12;
                        }});

                    }
                }
                if (isImageClicked(mouseX, mouseY, duck2ImageViewLevel6)){
                    killDuck(duck2ImageViewLevel6, duck2AnimationLevel6, gamePane6);
                    duck2ImageViewLevel6.setImage(null);
                    duckLeftLevel6 -= 1;
                    if (duckLeftLevel6 == 0) {
                        gamePane6.getChildren().remove(ammoTextLevel6);
                        ammoLeftLevel6= 12;
                        duckLeftLevel6 = 4;
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GAME_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        Text LevelCompleted = CreateText.createText("You have completed the game!");
                        Text startText2 = CreateText.createBlinkingText("PRESS ENTER TO START");
                        Text exitTest2 = CreateText.createBlinkingText("PRESS ESC TO EXIT");
                        VBox texts2 = new VBox();
                        texts2.getChildren().addAll(LevelCompleted, startText2, exitTest2);
                        texts2.setAlignment(Pos.CENTER);
                        texts2.setTranslateY(-50 * SCALE);
                        gamePane6.getChildren().add(texts2);
                        texts2.setVisible(true);
                        gameScene6.setOnKeyPressed(eventLevel6 -> {
                            if (eventLevel6.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                window.setScene(gameScene1);
                                duckImageView.setImage(new Image("assets/duck_black/4.png"));
                                duckImageView.setVisible(true);
                                duckAnimation.play();
                                gamePane6.getChildren().remove(texts2);
                                ammoLeftLevel1 = 3;
                                ammoLeftLevel2= 3;
                                ammoLeftLevel3= 6;
                                ammoLeftLevel4= 6;
                                ammoLeftLevel5= 9;
                                ammoLeftLevel6= 12;
                            }else if(eventLevel6.getCode() == KeyCode.ESCAPE){
                                mediaPlayer.stop();
                                window.setScene(titleScene);
                                gamePane6.getChildren().remove(texts2);
                                ammoLeftLevel1 = 3;
                                ammoLeftLevel2= 3;
                                ammoLeftLevel3= 6;
                                ammoLeftLevel4= 6;
                                ammoLeftLevel5= 9;
                                ammoLeftLevel6= 12;
                            }
                        });
                    }
                }
                if (isImageClicked(mouseX, mouseY, duck3ImageViewLevel6)) {
                    killDuck(duck3ImageViewLevel6, duck3AnimationLevel6, gamePane6);
                    duck3ImageViewLevel6.setImage(null);
                    duckLeftLevel6 -= 1;
                    if (duckLeftLevel6 == 0) {
                        gamePane6.getChildren().remove(ammoTextLevel6);
                        ammoLeftLevel6= 12;
                        duckLeftLevel6 = 4;
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GAME_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        Text LevelCompleted = CreateText.createText("You have completed the game!");
                        Text startText2 = CreateText.createBlinkingText("PRESS ENTER TO START");
                        Text exitTest2 = CreateText.createBlinkingText("PRESS ESC TO EXIT");
                        VBox texts2 = new VBox();
                        texts2.getChildren().addAll(LevelCompleted, startText2, exitTest2);
                        texts2.setAlignment(Pos.CENTER);
                        texts2.setTranslateY(-50 * SCALE);
                        texts2.setVisible(true);
                        gamePane6.getChildren().add(texts2);
                        gameScene6.setOnKeyPressed(eventLevel6 -> {
                            if (eventLevel6.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                window.setScene(gameScene1);
                                duckImageView.setImage(new Image("assets/duck_black/4.png"));
                                duckImageView.setVisible(true);
                                duckAnimation.play();
                                gamePane6.getChildren().remove(texts2);
                                ammoLeftLevel1 = 3;
                                ammoLeftLevel2= 3;
                                ammoLeftLevel3= 6;
                                ammoLeftLevel4= 6;
                                ammoLeftLevel5= 9;
                                ammoLeftLevel6= 12;
                            }else if(eventLevel6.getCode() == KeyCode.ESCAPE){
                                mediaPlayer.stop();
                                window.setScene(titleScene);
                                gamePane6.getChildren().remove(texts2);
                                ammoLeftLevel1 = 3;
                                ammoLeftLevel2= 3;
                                ammoLeftLevel3= 6;
                                ammoLeftLevel4= 6;
                                ammoLeftLevel5= 9;
                                ammoLeftLevel6= 12;
                            }
                        });

                    }
                }
                if (isImageClicked(mouseX, mouseY, duck4ImageViewLevel6)) {
                    killDuck(duck4ImageViewLevel6, duck4AnimationLevel6, gamePane6);
                    duck4ImageViewLevel6.setImage(null);
                    duckLeftLevel6 -= 1;
                    if (duckLeftLevel6 == 0) {
                        gamePane6.getChildren().remove(ammoTextLevel6);
                        ammoLeftLevel6= 12;
                        duckLeftLevel6 = 4;
                        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GAME_COMPLETED_SOUND_PATH)).toString()));
                        mediaPlayer.play();
                        Text LevelCompleted = CreateText.createText("You have completed the game!");
                        Text startText2 = CreateText.createBlinkingText("PRESS ENTER TO START");
                        Text exitTest2 = CreateText.createBlinkingText("PRESS ESC TO EXIT");
                        VBox texts2 = new VBox();
                        texts2.getChildren().addAll(LevelCompleted, startText2, exitTest2);
                        texts2.setAlignment(Pos.CENTER);
                        texts2.setTranslateY(-50 * SCALE);
                        texts2.setVisible(true);
                        gamePane6.getChildren().add(texts2);
                        gameScene6.setOnKeyPressed(eventLevel6 -> {
                            if (eventLevel6.getCode() == KeyCode.ENTER){
                                mediaPlayer.stop();
                                window.setScene(gameScene1);
                                duckImageView.setImage(new Image("assets/duck_black/4.png"));
                                duckImageView.setVisible(true);
                                duckAnimation.play();
                                gamePane6.getChildren().remove(texts2);
                                ammoLeftLevel1 = 3;
                                ammoLeftLevel2= 3;
                                ammoLeftLevel3= 6;
                                ammoLeftLevel4= 6;
                                ammoLeftLevel5= 9;
                                ammoLeftLevel6= 12;
                            }else if(eventLevel6.getCode() == KeyCode.ESCAPE){
                                mediaPlayer.stop();
                                window.setScene(titleScene);
                                gamePane6.getChildren().remove(texts2);
                                ammoLeftLevel1 = 3;
                                ammoLeftLevel2= 3;
                                ammoLeftLevel3= 6;
                                ammoLeftLevel4= 6;
                                ammoLeftLevel5= 9;
                                ammoLeftLevel6= 12;
                            }
                        });

                    }
                }
                ammoLeftLevel6 -= 1;
                ammoTextLevel6.setText("Ammo Left: " + ammoLeftLevel6);
                if (ammoLeftLevel6 == 0 && duckLeftLevel6 > 0) {

                    gameScene6.setOnKeyPressed(eventLevel6 -> {
                        if (eventLevel6.getCode() == KeyCode.ESCAPE) {
                            mediaPlayer.stop();
                            window.setScene(titleScene);
                            gamePane6.getChildren().remove(textsGameOver);
                            gamePane6.getChildren().remove(ammoTextLevel6);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoLeftLevel3 = 6;
                            ammoLeftLevel4 = 6;
                            ammoLeftLevel5 = 9;
                            ammoLeftLevel6 = 12;
                            ammoTextLevel1.setText("Ammo Left: " + ammoLeftLevel1);
                            ammoTextLevel2.setText("Ammo Left: " + ammoLeftLevel2);
                            ammoTextLevel3.setText("Ammo Left: " + ammoLeftLevel3);
                            ammoTextLevel4.setText("Ammo Left: " + ammoLeftLevel4);
                            ammoTextLevel5.setText("Ammo Left: " + ammoLeftLevel5);
                            ammoTextLevel6.setText("Ammo Left: " + ammoLeftLevel6);
                        }
                        if (eventLevel6.getCode() == KeyCode.ENTER) {
                            mediaPlayer.stop();
                            window.setScene(gameScene1);
                            gamePane6.getChildren().remove(textsGameOver);
                            gamePane6.getChildren().remove(ammoTextLevel6);
                            ammoLeftLevel1 = 3;
                            ammoLeftLevel2 = 3;
                            ammoLeftLevel3 = 6;
                            ammoLeftLevel4 = 6;
                            ammoLeftLevel5 = 9;
                            ammoLeftLevel6 = 12;
                            ammoTextLevel6.setText("Ammo Left: " + ammoLeftLevel6);
                        }
                    });
                    handleGameOver(6);
                }
            }

        });

        /**
         * Sets the scene to the title scene, displays the window, and starts playing the title music.
         * Configures the media player with the title music file and volume settings.
         * Sets the cycle count of the media player to indefinite for continuous playback.
         */
        window.setScene(titleScene);
        window.show();
        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource("assets/effects/Title.mp3")).toString()));
        mediaPlayer.setVolume(VOLUME);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
        mediaPlayer.play();



    }

    @Override
    public void handle(ActionEvent event) {

    }
    /**
     *Checks if the specified coordinates are within the bounds of the given ImageView.
     *@param mouseX The x-coordinate of the mouse click.
     *@param mouseY The y-coordinate of the mouse click.
     *@param duckImageView The ImageView to check against.
     *@return {@code true} if the coordinates are within the bounds of the ImageView, {@code false} otherwise.
     */
    private boolean isImageClicked(double mouseX, double mouseY, ImageView duckImageView) {
        double imageX = duckImageView.getBoundsInParent().getMinX();
        double imageY = duckImageView.getBoundsInParent().getMinY();
        double imageWidth = duckImageView.getBoundsInParent().getWidth();
        double imageHeight = duckImageView.getBoundsInParent().getHeight();


        return mouseX >= imageX && mouseX <= (imageX + imageWidth) &&
                mouseY >= imageY && mouseY <= (imageY + imageHeight);
    }
    /**
     *Performs actions when a duck is killed, including animation and sound effects.
     *@param duckImageView The ImageView of the killed duck.
     *@param duckAnimation The Timeline animation of the duck.
     *@param gamePane The StackPane containing the game elements.
     */
    private void killDuck(ImageView duckImageView,Timeline duckAnimation,StackPane gamePane) {
        duckAnimation.stop();
        String imageViewId = duckImageView.getId();

        if (imageViewId.equals("duckImageView")){
            duckShotImage.setImage(new Image("assets/duck_black/7.png"));
            duckFallImage.setImage(new Image("assets/duck_black/8.png"));
            right = isGoingRight1.get();
        }else if(imageViewId.equals("duckImageViewLevel2")){
            duckShotImage.setImage(new Image("assets/duck_blue/7.png"));
            duckFallImage.setImage(new Image("assets/duck_blue/8.png"));
            right = isGoingRight1.get();
        }else if(imageViewId.equals("duck1ImageViewLevel3")){
            duckShotImage.setImage(new Image("assets/duck_black/7.png"));
            duckFallImage.setImage(new Image("assets/duck_black/8.png"));
            right = isGoingRight1.get();
        }else if(imageViewId.equals("duck2ImageViewLevel3")){
            duckShotImage.setImage(new Image("assets/duck_blue/7.png"));
            duckFallImage.setImage(new Image("assets/duck_blue/8.png"));
            right = isGoingRight3.get();
        }else if(imageViewId.equals("duck1ImageViewLevel4")){
            duckShotImage.setImage(new Image("assets/duck_black/7.png"));
            duckFallImage.setImage(new Image("assets/duck_black/8.png"));
            right = isGoingRight1.get();
        }else if(imageViewId.equals("duck2ImageViewLevel4")){
            duckShotImage.setImage(new Image("assets/duck_blue/7.png"));
            duckFallImage.setImage(new Image("assets/duck_blue/8.png"));
            right = isGoingRight2.get();
        }else if(imageViewId.equals("duck1ImageViewLevel5")){
            duckShotImage.setImage(new Image("assets/duck_black/7.png"));
            duckFallImage.setImage(new Image("assets/duck_black/8.png"));
            right = isGoingRight1.get();
        }else if(imageViewId.equals("duck2ImageViewLevel5")){
            duckShotImage.setImage(new Image("assets/duck_blue/7.png"));
            duckFallImage.setImage(new Image("assets/duck_blue/8.png"));
            right = isGoingRight2.get();
        }else if(imageViewId.equals("duck3ImageViewLevel5")){
            duckShotImage.setImage(new Image("assets/duck_red/7.png"));
            duckFallImage.setImage(new Image("assets/duck_red/8.png"));
            right = isGoingRight3.get();
        }else if(imageViewId.equals("duck1ImageViewLevel6")){
            duckShotImage.setImage(new Image("assets/duck_black/7.png"));
            duckFallImage.setImage(new Image("assets/duck_black/8.png"));
            right = isGoingRight1.get();
        }else if(imageViewId.equals("duck2ImageViewLevel6")){
            duckShotImage.setImage(new Image("assets/duck_blue/7.png"));
            duckFallImage.setImage(new Image("assets/duck_blue/8.png"));
            right = isGoingRight2.get();
        }else if(imageViewId.equals("duck3ImageViewLevel6")){
            duckShotImage.setImage(new Image("assets/duck_red/7.png"));
            duckFallImage.setImage(new Image("assets/duck_red/8.png"));
            right = isGoingRight3.get();
        }else if(imageViewId.equals("duck4ImageViewLevel6")){
            duckShotImage.setImage(new Image("assets/duck_blue/7.png"));
            duckFallImage.setImage(new Image("assets/duck_blue/8.png"));
            right = isGoingRight4.get();
        }


        if (this.right){
            duckFallImage.setScaleX(1);
            duckShotImage.setScaleX(1);
        }else{
            duckFallImage.setScaleX(-1);
            duckShotImage.setScaleX(-1);
        }

        duckFallImage.setFitWidth(duckImageView.getImage().getWidth() * SCALE);
        duckFallImage.setFitHeight(duckImageView.getImage().getHeight() * SCALE);
        duckFallImage.setTranslateX(duckImageView.getTranslateX());
        duckFallImage.setTranslateY(duckImageView.getTranslateY());

        duckShotImage.setFitWidth(duckShotImage.getImage().getWidth() * SCALE);
        duckShotImage.setFitHeight(duckShotImage.getImage().getHeight() * SCALE);
        duckShotImage.setTranslateX(duckImageView.getTranslateX());
        duckShotImage.setTranslateY(duckImageView.getTranslateY());

        // Add the falling duck to the game pane
        gamePane.getChildren().addAll(duckFallImage);
        TranslateTransition fallAnimation = new TranslateTransition(Duration.seconds(1), duckFallImage);
        fallAnimation.setToY(WINDOW_HEIGHT * SCALE - duckFallImage.getFitHeight());
        fallAnimation.setInterpolator(Interpolator.EASE_IN);

        // Remove the fallen duck after the animation is completed
        fallAnimation.setOnFinished(event -> gamePane.getChildren().remove(duckFallImage));

        Duration duration = new Duration(500);
        gamePane.getChildren().add(duckShotImage);
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, e -> {
                    duckShotImage.setVisible(true);
                    this.duckImageView.setVisible(false);
                }),
                new KeyFrame(duration, e -> duckShotImage.setVisible(false))
        );
        timeline.play();

        // After the specified duration, remove the duckShotImage from the gamePane
        timeline.setOnFinished(e -> {
            this.duckImageView.setVisible(false);
            gamePane.getChildren().remove(duckShotImage);
            fallAnimation.play(); // Start the fall animation
        });

        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(DUCK_FALLS_SOUND_PATH)).toString()));
        mediaPlayer.play();

        PauseTransition pauseTransition = new PauseTransition(Duration.seconds(1));
        pauseTransition.setOnFinished(event -> {
        });
        pauseTransition.play();
    }
    /**
     *Sets the position and font of the given level text.
     *@param levelText The level text to be styled.
     */
    private void setLevelText(Text levelText){
        levelText.setTranslateX((WINDOW_WIDTH -250 ) * SCALE);
        levelText.setTranslateY(9 * SCALE);
        levelText.setTranslateY((WINDOW_HEIGHT -380 ) * SCALE);
        levelText.setFont(Font.font("Arial", FontWeight.BOLD, 7* SCALE));

    }
    /**
     *Sets the position and font of the given ammo text.
     *@param ammoText The ammo text to be styled.
     */
    private void setAmmoText(Text ammoText){
        ammoText.setTranslateX((WINDOW_WIDTH -190 ) * SCALE);
        ammoText.setTranslateY((WINDOW_HEIGHT -380 ) * SCALE);
        ammoText.setFont(Font.font("Arial", FontWeight.BOLD, 7* SCALE));
    }
    /**
     *Creates an HBox containing game texts based on the given level.
     *@param level The level of the game.
     *@return The HBox containing the game texts for the given level.
     */
    private HBox createGameTexts(int level){
        gameTexts = new HBox();
        switch(level){
            case 1:
                gameTexts.getChildren().addAll(levelText1, ammoTextLevel1);
                break;
            case 2:
                gameTexts.getChildren().addAll(levelText2, ammoTextLevel2);
                break;
            case 3:
                gameTexts.getChildren().addAll(levelText3, ammoTextLevel3);
                break;
            case 4:
                gameTexts.getChildren().addAll(levelText4, ammoTextLevel4);
                break;
            case 5:
                gameTexts.getChildren().addAll(levelText5, ammoTextLevel5);
                break;
            case 6:
                gameTexts.getChildren().addAll(levelText6, ammoTextLevel6);
                break;
        }

        gameTexts.setAlignment(Pos.CENTER);
        return gameTexts;

    }
    /**
     *Creates a VBox containing level completed text.
     *@return The VBox containing the level completed text.
     */
    private VBox createLevelCompletedText(){
        Text textGameOver = CreateText.createText("YOU WIN!");
        Text textEnter = CreateText.createBlinkingText("Press ENTER to play next level");

        VBox LevelCompletedText = new VBox(textGameOver, textEnter);
        LevelCompletedText.setAlignment(Pos.CENTER);
        LevelCompletedText.setTranslateY(-30 * SCALE);

        return LevelCompletedText;
    }
    /**
     *Handles the game over event for the specified level.
     *Displays "GAME OVER!" message along with instructions to play again or exit.
     *@param level the level of the game
     */
    private void handleGameOver(int level) {

        Text textGameOver = CreateText.createText("GAME OVER!");
        Text textEnter = CreateText.createBlinkingText("Press ENTER to play again");
        Text textESC = CreateText.createBlinkingText("Press ESC to exit");

        textsGameOver = new VBox(textGameOver, textEnter, textESC);
        textsGameOver.setAlignment(Pos.CENTER);
        textsGameOver.setTranslateY(-30 * SCALE);

        switch (level){
            case 1:
                gamePane1.getChildren().add(textsGameOver);
                break;
            case 2:
                gamePane2.getChildren().add(textsGameOver);
                break;
            case 3:
                gamePane3.getChildren().add(textsGameOver);
                break;
            case 4:
                gamePane4.getChildren().add(textsGameOver);
                break;
            case 5:
                gamePane5.getChildren().add(textsGameOver);
                break;
            case 6:
                gamePane6.getChildren().add(textsGameOver);
                break;


        }

        mediaPlayer = new MediaPlayer(new Media(Objects.requireNonNull(getClass().getResource(GAME_OVER_SOUND_PATH)).toString()));
        mediaPlayer.setVolume(VOLUME);
        mediaPlayer.play();

    }

    /**
     * Sets the size of the provided ImageView based on the predefined constants WINDOW_WIDTH and WINDOW_HEIGHT,
     * multiplied by the specified scale factor.
     *
     * @param background the ImageView object to resize
     */
    private void setSize(ImageView background){
        background.setFitWidth(WINDOW_WIDTH * SCALE);
        background.setFitHeight(WINDOW_HEIGHT * SCALE);
    }
}
