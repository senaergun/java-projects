import javafx.animation.FadeTransition;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;
/**
 *The CreateText class provides utility methods for creating JavaFX Text objects.
 */
public class CreateText {
    /**
     *The duration of the blinking animation.
     */
    private static final Duration BLINK_DURATION = Duration.seconds(1.2);
    /**
     *Creates a Text object with the specified text.
     *@param text The text to be displayed.
     *@return The created Text object.
     */
    public static Text createText(String text) {
        Text createdText = new Text(text);
        createdText.setFont(Font.font("Arial", FontWeight.BOLD, 10* DuckHunt.SCALE));
        createdText.setFill(Color.ORANGE);

        return createdText;
    }
    /**
     *Creates a Text object with the specified text that blinks.
     *@param text The text to be displayed.
     *@return The created Text object that blinks.
     */

    public static Text createBlinkingText(String text) {
        Text blinkingText = new Text(text);
        blinkingText.setFont(Font.font("Arial", FontWeight.BOLD, 10* DuckHunt.SCALE));
        blinkingText.setFill(Color.ORANGE);

        FadeTransition fadeTransition = new FadeTransition(BLINK_DURATION, blinkingText);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0.0);
        fadeTransition.setCycleCount(FadeTransition.INDEFINITE);
        fadeTransition.setAutoReverse(true);
        fadeTransition.play();

        return blinkingText;
    }
}
