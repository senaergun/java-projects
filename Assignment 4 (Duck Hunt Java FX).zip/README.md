Please specify the location (e.g. src/ or src/mypackage) 
where your implementation should be compiled at:
/////////// Type Below: src/ ///////////

///////////////////////////////////////////////////


Please specify the command that is needed 
to COMPILE your implementation:
(e.g. javac Main.java)
Note that any external libraries are not allowed!
///////////// Type Below: javac DuckHunt.java //////////////

///////////////////////////////////////////////////


Please specify the command that is needed 
to RUN your implementation:
(e.g. java Main)
Note that any external libraries are not allowed!
///////////////// Type Below: java DuckHunt /////////////////

///////////////////////////////////////////////////

Please specify the location (e.g. src/ or src/mypackage)
where assets folder should be inserted:
////////// Type Below: src/ //////////

///////////////////////////////////////////////////

Please specify extra information if you have any
////////// Type Below: EXTRA INFORMATION //////////

///////////////////////////////////////////////////