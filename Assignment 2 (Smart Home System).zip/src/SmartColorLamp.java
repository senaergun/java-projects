/**
 *SmartColorLamp is a subclass of SmartLamp that allows users to set the color of the lamp.
 *It inherits the functionality of the SmartLamp class and adds a new method, setColorCode, to set the color of the lamp.
 *The color is represented by a hexadecimal color code.
 */
public class SmartColorLamp extends SmartLamp{
    /**
     *The hexadecimal color code of the lamp.
     *Initialized to -1, which represents no color has been set.
     */
    private int colorCode = -1;

    /**
     *Returns the current color code of the lamp.
     *@return The color code of the lamp
     */
    public int getColorCode() {
        return colorCode;
    }

    /**
     *Sets the color of the lamp using a hexadecimal color code.
     *@param colorCode The hexadecimal color code of the color to set
     *@return True if the color code was successfully set, false otherwise
     */
    public boolean setColorCode(int colorCode) {

        boolean allOK = true;
        if (colorCode <=  0xFFFFFF && colorCode >= 0x000000){
            this.colorCode = colorCode;
        }
        else{
            allOK = false;
            Main.writer.println("ERROR: Color code value must be in range of 0x0-0xFFFFFF!");
        }
        return allOK;

    }

    /**
     *Sets the color of the lamp using a hexadecimal color code and a brightness value.
     *@param colorCode The hexadecimal color code of the color to set
     *@param brightness The brightness level of the lamp, in the range of 0%-100%
     */
    @Override
    public void setColor(int colorCode, int brightness) {
        int oldColorCode = this.colorCode;
        boolean allOK = this.setColorCode(colorCode);
        if (allOK){
            allOK &= this.setBrightness(brightness);
            if (!allOK) {

                // Change back the color code if brightness could not be set
                this.colorCode = oldColorCode;
            }
        }
    }

    /**
     *Prints the status of the SmartColorLamp object, including the color, brightness, and switch time.
     *If the color has not been set, only the kelvin and brightness values are printed.
     */
    @Override
    public void printDeviceStatus() {
        if ( this.colorCode == -1 ){
            Main.writer.println("Smart Color Lamp " + this.name + " is " + this.status + " and its color value is " +
                    this.kelvin + "K with " + this.brightness +  "% brightness, and its time to switch its status is "
                    + this.switchTimeString + ".");
        } else {
            Main.writer.println("Smart Color Lamp " + this.name + " is " + this.status + " and its color value is " +
                    decimalToHex(this.colorCode) + " with " + this.brightness +  "% brightness, and its time to switch its status is "
                    + this.switchTimeString + ".");
        }

    }

    /**
     *Converts a decimal integer to a hexadecimal string representation.
     *@param colorCode The decimal integer to convert to a hexadecimal string
     *@return The hexadecimal string representation of the decimal integer
     */
    public static String decimalToHex(int colorCode) {
        // return String.format("%06X", Integer.toHexString(colorCode)).toUpperCase().replace(' ', '0');
        return "0x" + String.format("%06X", Integer.valueOf(colorCode));
    }

    @Override
    public boolean isSmartColorLamp() {
        return true;
    }
}
