import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
/**

 This class represents a smart home system that manages a list of smart devices
 and provides methods to add, remove, switch and check their status based on the system time.
 */
public class SmartHomeSystem {

    /**
     * A map of smart devices associated with their names.
     */
    public Map<String, SmartDevice> deviceList;

    /**
     * The current time of the smart home system.
     */
    public LocalDateTime time;

    /**
     * Creates a new SmartHomeSystem object with an empty device list.
     */
    public SmartHomeSystem() {

        this.deviceList = new LinkedHashMap<String, SmartDevice>();
    }

    /**
     * Returns the current time of the smart home system.
     *
     * @return the current time of the smart home system.
     */
    public LocalDateTime getTime() {
        return time;
    }

    /**
     * Sets the current time of the smart home system and checks for expired switch times
     * to switch the devices accordingly.
     *
     * @param time the time to set for the smart home system.
     */
    public void setTime(LocalDateTime time) {
        if (this.time == null) {
            this.time = time;
        }
        else if (time.isAfter(this.time) || (time.isEqual(this.time))) {
            this.time = time;
            // Check the switch times and switch the devices with expired switch times
            checkSwitchTimes();
        } else {
            Main.writer.println("ERROR: Time cannot be reversed!");
        }
    }

    /**
     * Advances the current time of the smart home system by the given number of minutes
     * and checks for expired switch times to switch the devices accordingly.
     *
     * @param minute the number of minutes to skip.
     */
    public void skipMinutes(int minute) {
        if (minute > 0){
            this.time = this.time.plusMinutes(minute);
            // Check the switch times and switch the devices with expired switch times
            checkSwitchTimes();
        } else if( minute == 0) {
            Main.writer.println("ERROR: There is nothing to skip!");
        }else{
            Main.writer.println("ERROR: Time cannot be reversed!");

        }

    }
    /**
     * Skips to the next switch time of any of the devices and switches them accordingly.
     * If there are no devices with switch times, prints an error message.
     */
    public void nop() {
        LocalDateTime firstSwitchTime = null;

        for (Map.Entry<String, SmartDevice> entry : deviceList.entrySet()) {

            // Get device from the list
            SmartDevice device = entry.getValue();

            // Find the first switch time if any
            LocalDateTime switchTime = device.getSwitchTime();
            if (switchTime != null) {
                if (this.time.isBefore(switchTime)) {
                    if (firstSwitchTime == null) {
                        firstSwitchTime = switchTime;
                    } else if(switchTime.isBefore(firstSwitchTime)) {
                        firstSwitchTime = switchTime;
                    }
                }
            }
        }

        if (firstSwitchTime != null) {
            this.time = firstSwitchTime;
            checkSwitchTimes();
        } else {

            Main.writer.println("ERROR: There is nothing to switch!");
        }
    }
    public int numDevices = 0;

    /**
     * Adds a smart device to the device list of the smart home system.
     * If there is already a device with the same name, prints an error message.
     *
     * @param device the smart device to be added.
     */
    public void addDevice(SmartDevice device) {

        if (deviceList.containsKey(device.getName())) {

            Main.writer.println("ERROR: There is already a smart device with same name!");
        } else {
            deviceList.put(device.getName(), device);
            numDevices++;
        }
    }
    /**
     * Removes the smart device with the given name from the device list of the smart home system,
     * switches it off and prints its status information.
     * If there is no device with that name, it gives an error
     */
    public void removeDevice(String name) {

        if (deviceList.containsKey(name)) {

            SmartDevice device = deviceList.get(name);
            device.status = deviceStatus.off;
            device.switchOff();
            deviceList.remove(device.getName());
            Main.writer.println("SUCCESS: Information about removed smart device is as follows:");
            device.printDeviceStatus();

        } else {
            Main.writer.println("ERROR: There is not such a device!");
        }
    }
    /**
     *Checks the switch time of each device in the deviceList and switches the device
     *if the switch time has expired.
     */
    private void checkSwitchTimes() {

        for (Map.Entry<String, SmartDevice> entry : deviceList.entrySet()) {

            // Get device from the list
            SmartDevice device = entry.getValue();

            // Check switch time of the device and switch if expired
            LocalDateTime switchTime = device.getSwitchTime();
            if (switchTime != null) {
                if (this.time.isAfter(switchTime) || this.time.isEqual(switchTime)) {
                    device.switchDevice();
                }
            }
        }
    }
    /**

     Returns the SmartDevice object with the given name.
     @param name The name of the SmartDevice object to be returned.
     @return The SmartDevice object with the given name, or null if no such SmartDevice exists.
     */
    public SmartDevice getDevice(String name){
        return this.deviceList.get(name);

    }

    /**
     *Changes the name of a SmartDevice object in the deviceList.
     *@param name The current name of the SmartDevice object.
     *@param newName The new name for the SmartDevice object.
     */
    public void changeName(String name, String newName) {
        boolean allOk = true;
        SmartDevice device;
        device = this.deviceList.get(name);

        if (newName.equals(name)) {
            Main.writer.println("ERROR: Both of the names are the same, nothing changed!");
            return;
        }

        if (device == null) {
            Main.writer.println("ERROR: Erroneous command!");
            return;
        }

        if (deviceList.containsKey(newName)) {
            Main.writer.println("ERROR: There is already a smart device with same name!");
            return;
        }

        // create a new HashMap
        Map<String, SmartDevice> updatedMap = new LinkedHashMap<>();

        for (Map.Entry<String, SmartDevice> entry : deviceList.entrySet()) {

            if (entry.getKey().equals(name)) {
                updatedMap.put(newName, entry.getValue());
                entry.getValue().setName(newName);
            } else {
                updatedMap.put(entry.getKey(), entry.getValue());
            }
        }

        deviceList = updatedMap;
    }



    public void printReport() {
        Main.writer.println("Time is:\t" + this.time.format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss")));
        // Sort and print device info
        List<SmartDevice> sortedList = new ArrayList<>(deviceList.values());
        Collections.sort(sortedList);

        for (SmartDevice device : sortedList) {
            device.printDeviceStatus();
        }
    }
}

