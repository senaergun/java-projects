import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

enum deviceStatus {
    off,
    on
}

/**
 *This abstract class represents a SmartDevice with basic properties and methods.
 *It is designed to be extended by various types of smart devices such as smart plugs, lamps, etc.
 */

abstract public class SmartDevice implements Comparable<SmartDevice> {
    protected String name;

    /**
     *The time when the device was last switched on/off.
     */
    protected LocalDateTime switchTime = null;

    /**
     *The formatted string representation of the switchTime property.
     */
    protected String switchTimeString = "null";

    /**
     *The time when this device started consuming power.
     */
    protected LocalDateTime consumptionStartTime;
    public deviceStatus status;

    /**
     *Returns the status of this device.
     *@return the status of this device
     */
    public deviceStatus getStatus() {
        return status;
    }

    /**
     *Returns the name of this device.
     *@return the name of this device
     */
    public String getName() {
        return name;
    }

    /**
     *Sets the name of this device.
     *@param name the new name for this device
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *Sets the status of this device.
     *@param status the new status for this device
     *@return true if the status was successfully set, false otherwise
     */
    public boolean setDeviceStatus(deviceStatus status) {

        boolean allOK = true;

        if (this.status == status) {

            if(this.status == deviceStatus.on){

                Main.writer.println("ERROR: This device is already switched on!");
            }else {

                Main.writer.println("ERROR: This device is already switched off!");
            }
            allOK = false;
        } else {

            this.status = status;
            this.switchTime = null;
            this.switchTimeString = "null";

            if (status == deviceStatus.on) {

                // Device specific switch on
                switchOn();
            } else {

                // Device specific switch off
                switchOff();
            }
        }
        return allOK;
    }

    /**
     *Toggles the status of this device at each call.
     */
    public void switchDevice() {
        this.switchTime = null;
        this.switchTimeString = "null";

        if (this.status == deviceStatus.on) {
            this.status = deviceStatus.off;
            this.switchOff();
        } else {
            this.status = deviceStatus.on;
            this.switchOn();
        }
    }
    /**
     *Performs device-specific actions upon switch on.
     *This method should be overridden by the subclasses.
     */
    protected void switchOn() {
    }

    /**
     *Performs device-specific actions upon switch off.
     *This method should be overridden by the subclasses.
     */
    abstract void switchOff();

    /**
     *Prints the current status of this device.
     *This method should be overridden by the subclasses.
     */
    abstract void printDeviceStatus();


    /**
     *This default implementation gives an error message.
     *Plug devices should override this default implementation.
     *@param ampere the amperage for this device
     */
    public boolean plugIn(float ampere) {
        Main.writer.println("ERROR: This device is not a smart plug!");
        return false;
    }

    /**
     *This default implementation gives an error message.
     *Plug devices should override this default implementation.
     */
    public void plugOut() {
        Main.writer.println("ERROR, this device is not a smart plug!");
    }

    /**
     *This default implementation gives an error message.
     * Smart Lamps should override this default implementation.
     */
    public boolean setKelvin(int kelvin) {
        Main.writer.println("ERROR: This device is not a smart lamp!");
        return false;
    }

    /**
     *This default implementation gives an error message.
     * Smart Lamps should override this default implementation.
     */
    public boolean setBrightness(int brightness) {
        Main.writer.println("ERROR: This device is not a smart lamp!");
        return false;
    }

    /**
     *This default implementation gives an error message.
     * Smart Color Lamps should override this default implementation.
     */
    public boolean setColorCode(int colorCode) {
        Main.writer.println("ERROR: This device is not a smart color lamp!");
        return false;
    }

    /**
     *This default implementation gives an error message.
     * Smart Lamps should override this default implementation.
     */
    public void setWhite(int kelvin, int brightness) {
        Main.writer.println("ERROR: This device is not a smart lamp!");
    }

    /**
     *This default implementation gives an error message.
     * Smart Color Lamps should override this default implementation.
     */
    public void setColor(int colorCode, int brightness) {
        Main.writer.println("ERROR: This device is not a smart color lamp!");
    }

    /**
     *Sets the switch time of the device.
     *@param switchTime a LocalDateTime object representing the time at which the device was switched.
     *@return void
     */
    public void setSwitchTime(LocalDateTime switchTime) {
        this.switchTime = switchTime;
        this.switchTimeString = this.switchTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss"));
    }

    /**
     *Gets the switch time of the device.
     *@return a LocalDateTime object representing the time at which the device was switched.
     */
    public LocalDateTime getSwitchTime() {

        return switchTime;
    }

    public boolean isSmartLamp() {
        return false;
    }

    public boolean isSmartCamera() {
        return false;
    }

    public boolean isSmartColorLamp() {
        return false;
    }

    public boolean isSmartPlug() {
        return false;
    }

    /**
     *Compares the switch times of this device and the specified device.
     *@param device the SmartDevice object to compare to.
     *@return an integer value indicating the order of the devices based on their switch times.
     *  return 0 if the switch times are equal, a negative integer if this device's switch time is earlier,
     *  and a positive integer if this device's switch time is later.
     */
    @Override
    public int compareTo(SmartDevice device) {

        int retVal;
        LocalDateTime switchTime = device.getSwitchTime();
        if (this.switchTime != null  && switchTime != null) {

            retVal = this.switchTime.compareTo(switchTime);

        } else if (this.switchTime != null && switchTime == null) {

            retVal = -1;

        } else if (this.switchTime == null && switchTime != null) {

            retVal = 1;

        } else {

            retVal = 0;
        }
        return retVal;
    }
}
