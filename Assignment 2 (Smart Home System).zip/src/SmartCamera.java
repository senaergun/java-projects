import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
/**
 *This class represents a Smart Camera, a subclass of SmartDevice.
 *It has a property of megabytes consumed per record and consumed storage, and can switch on or off, as well as print its status.
 */
public class SmartCamera extends SmartDevice{
    private float magabytesComsumedPerRecord;

    /**
     * Getter method for the megabytes consumed per record property.
     * @return the megabytes consumed per record
     */
    public float getMagabytesComsumedPerRecord() {
        return magabytesComsumedPerRecord;
    }

    private float consumedStorage = 0;

    /**
     * Setter method for the megabytes consumed per record property.
     * @param magabytesComsumedPerRecord the value to set as the megabytes consumed per record
     * @return true if the value is successfully set, false otherwise
     */
    public boolean setMagabytesComsumedPerRecord(float magabytesComsumedPerRecord) {

        boolean allOK = true;
        if ( magabytesComsumedPerRecord > 0){
            this.magabytesComsumedPerRecord = magabytesComsumedPerRecord;
        }else{
            allOK = false;
            Main.writer.println("ERROR: Megabyte value must be a positive number!");
        }
        return allOK;
    }


    /**
     * Switches the Smart Camera on and updates the last switch on time.
     */
    @Override
    protected void switchOn() {
        // Update last switch on time
        this.consumptionStartTime = Main.mySmartHomeSystem.getTime();
    }

    /**
     * Switches the Smart Camera off and updates the consumed storage if it has been switched on before.
     */
    @Override
    protected void switchOff() {
        if (this.consumptionStartTime != null) {
            long totalMinutes = ChronoUnit.MINUTES.between(this.consumptionStartTime, Main.mySmartHomeSystem.getTime());
            // Update total energy consumption
            this.consumedStorage += totalMinutes * this.magabytesComsumedPerRecord;
            this.consumptionStartTime = null;
        }
    }

    /**
     * Prints the status of the Smart Camera, including its name, status, consumed storage (excluding current status), and time to switch status.
     */
    @Override
    public void printDeviceStatus() {
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        df.setMinimumFractionDigits(2);
        Main.writer.println("Smart Camera " + this.name + " is " + this.status + " and used " +
                        df.format(this.consumedStorage) + " MB of storage so far (excluding current status), and its time to switch its status is " +
                        this.switchTimeString + ".");

    }

    @Override
    public boolean isSmartCamera() {
        return true;
    }
}
