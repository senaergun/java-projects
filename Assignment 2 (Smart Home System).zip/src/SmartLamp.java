import java.time.format.DateTimeFormatter;
/**
 *The SmartLamp class represents a smart lamp device that can be controlled through the SmartHomeSystem.
 *It extends the SmartDevice abstract class and implements its own methods for managing the lamp's brightness and kelvin values.
 */
public class SmartLamp extends SmartDevice{
    /**
     *The default kelvin value of the lamp.
     */
    protected int kelvin =  4000;

    /**
     *The default brightness value of the lamp.
     */
    protected int brightness = 100;

    /**
     *Returns the current brightness value of the lamp.
     *@return the current brightness value of the lamp.
     */
    public int getBrightness() {
        return brightness;
    }

    /**
     *Sets the brightness value of the lamp to the given value, if it is within the valid range of 0-100.
     *If the value is invalid, an error message is printed to the Main writer.
     *@param brightness the new brightness value to set.
     *@return true if the new value was set successfully, false otherwise.
     */
    public boolean setBrightness(int brightness) {

        boolean allOK = true;

        if (brightness >= 0 && brightness <=100){
            this.brightness = brightness;
        }else{
            allOK = false;
            Main.writer.println("ERROR: Brightness must be in range of 0%-100%!");
        }
        return allOK;

    }

    /**
     *Returns the current kelvin value of the lamp.
     *@return the current kelvin value of the lamp.
     */
    public int getKelvin() {
        return kelvin;
    }

    /**
     *Sets the kelvin value of the lamp to the given value, if it is within the valid range of 2000K-6500K.
     *If the value is invalid, an error message is printed to the Main writer.
     *@param kelvin the new kelvin value to set.
     *@return true if the new value was set successfully, false otherwise.
     */
    public boolean setKelvin(int kelvin) {
        boolean allOK = true;
        if (kelvin>= 2000 && kelvin <=6500){
            this.kelvin = kelvin;
        }else{
            allOK = false;
            Main.writer.println("ERROR: Kelvin value must be in range of 2000K-6500K!");
        }
        return allOK;

    }

    /**
     *Sets the kelvin and brightness values of the lamp to the given values.
     *If either value is invalid, an error message is printed to the Main writer.
     *@param kelvin the new kelvin value to set.
     *@param brightness the new brightness value to set.
     */
    public void setWhite(int kelvin, int brightness){
    boolean allOK = true;
    allOK = setKelvin(kelvin);
    if (allOK){
        setBrightness(brightness);
    }

    }
    /**
     *Overrides the abstract method in SmartDevice.
     *Currently does not perform any action when called.
     */
    @Override
    protected void switchOff() {

    }
    /**
     *Overrides the abstract method in SmartDevice.
     *Prints the current status of the lamp, including its name, kelvin value, brightness percentage,
     *and the time at which its status will switch.
     */
    @Override
    protected void printDeviceStatus() {

        Main.writer.println("Smart Lamp " + this.name + " is " + this.status +
                " and its kelvin value is " + this.kelvin + "K with " + this.brightness + "% brightness, and its time to switch its status is "
                + this.switchTimeString + ".");

    }

    @Override
    public boolean isSmartLamp() {
        return true;
    }
}
