import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
/**

 * A class that represents a Smart Plug, a device that can be plugged in to an electrical socket and controlled
 *remotely via a smart home system. This class extends the SmartDevice class.
 */
public class SmartPlug extends SmartDevice{
    private static final int volt = 220;

    private boolean isPluggedIn = false;
    private float ampere;

    private float totalConsumption = 0;

    /**

     *Returns the current ampere of the Smart Plug.
     *@return the current ampere of the Smart Plug.
     */
    public float getAmpere() {
        return ampere;
    }

    /**
     *Sets the ampere value of the Smart Plug.
     *@param ampere the ampere value to set.
     *@return a boolean indicating whether the set operation was successful.
     */
    public boolean setAmpere(float ampere)  {
        boolean allOK = true;

        if ( ampere > 0){
            this.ampere = ampere;
        }else{

            Main.writer.println("ERROR: Ampere value must be a positive number!");
            allOK = false;
        }
        return  allOK;

    }
    /**

     Switches on the Smart Plug and starts counting its energy consumption if it's plugged in.
     */
    @Override
    protected void switchOn() {
        if (isPluggedIn) {
            consumptionStartTime = Main.mySmartHomeSystem.getTime();
        }
    }

    /**

     Switches off the Smart Plug and calculates its energy consumption based on the time it was on, if it was plugged in.
     */
    @Override
    void switchOff() {
        if (this.consumptionStartTime != null) {
            long totalMinutes = ChronoUnit.MINUTES.between(this.consumptionStartTime, Main.mySmartHomeSystem.getTime());
            // Update total energy consumption
            this.totalConsumption += ((float)totalMinutes/60) * this.volt * this.ampere;
            consumptionStartTime = null;

        }
    }

    /**

     *Plugs in the Smart Plug to an electrical socket with the specified ampere.
     *@param ampere the ampere of the socket.
     */
    @Override
    public boolean plugIn(float ampere) {
        boolean allOK = true;

        if(isPluggedIn){
            Main.writer.println("ERROR: There is already an item plugged in to that plug!");
            allOK = false;
        }else{
            allOK = this.setAmpere(ampere);
            if (allOK) {
                isPluggedIn = true;
                if (this.status == deviceStatus.on) {
                    this.consumptionStartTime = Main.mySmartHomeSystem.getTime();
                }
            }

        }
        return allOK;
    }
    /**

     *Unplugs the Smart Plug from the electrical socket.
     */
    @Override
    public void plugOut() {
        if( !isPluggedIn){
            Main.writer.println("ERROR: This plug has no item to plug out from that plug!");
        }else{
            isPluggedIn = false;
            if (this.consumptionStartTime != null) {
                long totalMinutes = ChronoUnit.MINUTES.between(Main.mySmartHomeSystem.getTime(), this.consumptionStartTime);
                // Update total energy consumption
                this.totalConsumption += (totalMinutes/60) * this.volt * this.ampere;
                consumptionStartTime = null;
            } 

        }


    }
    /**

     *Prints the status of the Smart Plug, including its name, status, total energy consumption so far,
     *and the time to switch its status.
     */
    @Override
    public void printDeviceStatus() {
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        df.setMinimumFractionDigits(2);
        Main.writer.println("Smart Plug " + this.name + " is " + this.status + " and consumed " + df.format(this.totalConsumption) +
                "W so far (excluding current device), and its time to switch its status is " + this.switchTimeString + ".");
    }

    @Override
    public boolean isSmartPlug() {
        return true;
    }
}
