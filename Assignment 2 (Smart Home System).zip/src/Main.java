import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

/**

 The Main class represents the entry point of the application.
 It contains a main method that reads an input file, processes the commands
 and generates an output file.
 */
public class Main {

    /**
     A PrintWriter object used to write to the output file.
     */
    public static PrintWriter writer;

    /**
     A SmartHomeSystem object representing the smart home system of the application.
     */
    public static SmartHomeSystem mySmartHomeSystem;

    /**
     *The main method of the application that reads an input file, processes the commands,
     *and generates an output file.
     *@param args an array of command-line arguments
     *@throws IOException if an I/O error occurs while reading or writing the files
     */
    public static void main(String[] args) throws IOException {
        String[] linesInput = readFile(args[0]);
        for (String line : linesInput) {
        }

        // Convert the input file to a 2D string array
        int numRows = linesInput.length;
        int numCols = 10;
        String[][] inputList = new String[numRows][numCols];

        for (int i = 0; i < numRows; i++) {
            String[] lineString = linesInput[i].split("\t");
            inputList[i] = lineString;
        }

        // Create a new SmartHomeSystem object
        mySmartHomeSystem = new SmartHomeSystem();

        // Create a new PrintWriter object to write to the output file
        writer = new PrintWriter(args[1]);
        int numCommands = 0;

        //check if the first command is "SetInitialTime"
        for (String[] commandLine : inputList) {

            String command = commandLine[0];
            if (command.length() == 0 || command.equals("SetInitialTime")) {
                if (command.equals("SetInitialTime")) {
                    break;
                }else {
                }
            } else {
                // If the first command is not "SetInitialTime", write an error message to the output file
                StringBuilder stringBuilder = new StringBuilder();

                for (String str : commandLine) {
                    stringBuilder.append(str);
                    stringBuilder.append("    ");
                }
                writer.println("COMMAND:    " + stringBuilder.toString());
                writer.println("ERROR: First command must be set initial time! Program is going to terminate!");
                writer.close();
                System.exit(0);

            }
        }

        boolean initialTimeIsSet = false;
        boolean lastZReport = false;

        // Iterate all commands in the input list
        for (String[] commandLine : inputList) {
            int lenght = commandLine.length;

            boolean allOK = true;
            lastZReport = false;


            //print commands to screen
            if (commandLine[0].length() != 0) {

                StringBuilder stringBuilder = new StringBuilder();

                for (String str : commandLine) {

                    stringBuilder.append(str);
                    stringBuilder.append("\t");
                }
                writer.println("COMMAND: " + stringBuilder.toString());
            }

            String command = commandLine[0];
            switch (command) {
                case "SetInitialTime":
                    // Set initial time and change the variable "initialTimeIsSet"
                    if (!initialTimeIsSet){
                        try{
                            mySmartHomeSystem.setTime(LocalDateTime.parse(commandLine[1], DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss")));
                            writer.println("SUCCESS: Time has been set to " + commandLine[1] + "!");
                            initialTimeIsSet = true;
                        }catch (Exception e){
                            writer.println("ERROR: Format of the initial date is wrong! Program is going to terminate!\n");
                            writer.close();
                            System.exit(0);
                        }

                    } else {
                        writer.println("ERROR: Erroneous command!");
                    }
                    break;

                case "SetTime":
                    if (commandLine.length == 2){
                        try {
                            mySmartHomeSystem.setTime(LocalDateTime.parse(commandLine[1], DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss")));
                        } catch (Exception e) {
                            writer.println("ERROR: Time format is not correct!");
                        }
                    } else {
                        writer.println("ERROR: Erroneous command!");
                    }

                    break;

                case "SkipMinutes":
                    if (commandLine.length == 2){
                        try {
                            mySmartHomeSystem.skipMinutes(Integer.parseInt(commandLine[1]));
                        } catch (Exception e) {
                            writer.println("ERROR: Erroneous command!");
                        }
                    } else {
                        writer.println("ERROR: Erroneous command!");
                    }

                    break;

                case "Nop":
                    if (commandLine.length == 1){
                        mySmartHomeSystem.nop();

                    }
                    else{
                        writer.println("ERROR: Erroneous command!");

                    }
                    break;
                case "Add":
                    switch (commandLine[1]) {
                        case "SmartPlug":
                            SmartPlug plug = new SmartPlug();
                            switch (commandLine.length) {
                                case 3:
                                    // Set name and default status
                                    plug.setName(commandLine[2]);
                                    allOK &= plug.setDeviceStatus(deviceStatus.off);
                                    break;

                                case 4:
                                    // Set name
                                    plug.setName(commandLine[2]);

                                    // Check and set initial status
                                    switch (commandLine[3]) {
                                        case "On":
                                            allOK &= plug.setDeviceStatus(deviceStatus.on);
                                            break;
                                        case "Off":
                                            allOK &= plug.setDeviceStatus(deviceStatus.off);
                                            break;
                                        default:
                                            writer.println("ERROR: Erroneous command!");
                                            allOK = false;
                                    }
                                    break;
                                case 5:
                                    // Set name
                                    plug.setName(commandLine[2]);

                                    // Check and set initial status
                                    switch (commandLine[3]) {
                                        case "On":
                                            allOK &= plug.setDeviceStatus(deviceStatus.on);
                                            break;
                                        case "Off":
                                            allOK &= plug.setDeviceStatus(deviceStatus.off);
                                            break;
                                        default:
                                            writer.println("ERROR: Erroneous command!");
                                            allOK = false;

                                    }
                                    // Check and set ampere
                                    try {
                                        // allOK &= plug.setAmpere(Float.parseFloat(commandLine[4]));
                                        allOK &= plug.plugIn(Float.parseFloat(commandLine[4]));
                                    } catch (Exception e) {
                                        writer.println("ERROR: Erroneous command!");
                                        allOK = false;
                                    }

                                    break;
                                default:
                                    // False command error
                                    allOK = false;
                                    writer.println("ERROR: Erroneous command!");
                            }
                            if (allOK) {
                                //add the device to the device list
                                mySmartHomeSystem.addDevice(plug);
                            }
                            break;

                        case "SmartCamera":
                            SmartCamera camera = new SmartCamera();
                            switch (commandLine.length) {
                                case 4:
                                    // Set name and default status
                                    camera.setName(commandLine[2]);
                                    allOK &= camera.setDeviceStatus(deviceStatus.off);

                                    // Check and set magabytes comsumed per record
                                    try {
                                        allOK &= camera.setMagabytesComsumedPerRecord(Float.parseFloat(commandLine[3]));
                                    } catch (Exception e) {
                                        writer.println("ERROR: Erroneous command!");
                                    }
                                    break;

                                case 5:
                                    // Set name
                                    camera.setName(commandLine[2]);

                                    // Check and set magabytes comsumed per record
                                    try {
                                        allOK &= camera.setMagabytesComsumedPerRecord(Float.parseFloat(commandLine[3]));
                                    } catch (Exception e) {
                                        writer.println("ERROR: Erroneous command!");
                                    }

                                    // Check and set initial status
                                    switch (commandLine[4]) {
                                        case "On":
                                            allOK &= camera.setDeviceStatus(deviceStatus.on);
                                            break;
                                        case "Off":
                                            allOK &= camera.setDeviceStatus(deviceStatus.off);
                                            break;
                                        default:
                                            writer.println("ERROR: Erroneous command!");
                                            allOK = false;
                                    }
                                    break;
                                default:
                                    // False command error
                                    writer.println("ERROR: Erroneous command!");
                                    allOK = false;
                            }
                            if (allOK) {
                                //add the device to the device list
                                mySmartHomeSystem.addDevice(camera);
                            }
                            break;

                        case "SmartLamp":
                            SmartLamp lamp = new SmartLamp();

                            switch (commandLine.length) {
                                case 3:
                                    // Set name and default status
                                    lamp.setName(commandLine[2]);
                                    allOK &= lamp.setDeviceStatus(deviceStatus.off);
                                    break;
                                case 4:
                                    // Set name
                                    lamp.setName(commandLine[2]);

                                    // Check and set initial status
                                    switch (commandLine[3]) {
                                        case "On":
                                            allOK &= lamp.setDeviceStatus(deviceStatus.on);
                                            break;
                                        case "Off":
                                            allOK &= lamp.setDeviceStatus(deviceStatus.off);
                                            break;
                                        default:
                                            writer.println("ERROR: Erroneous command!");
                                            allOK = false;
                                    }

                                    break;
                                case 6:
                                    // Set name
                                    lamp.setName(commandLine[2]);

                                    // Check and set initial status
                                    switch (commandLine[3]) {
                                        case "On":
                                            allOK &= lamp.setDeviceStatus(deviceStatus.on);
                                            break;
                                        case "Off":
                                            allOK &= lamp.setDeviceStatus(deviceStatus.off);
                                            break;
                                        default:
                                            writer.println("ERROR: Erroneous command!");
                                            allOK = false;
                                    }

                                    // Check and set kelvin and brightness values
                                    try {
                                        allOK &= lamp.setKelvin(Integer.parseInt(commandLine[4]));
                                        if (allOK){
                                            allOK &= lamp.setBrightness(Integer.parseInt(commandLine[5]));
                                        }
                                    } catch (Exception e) {
                                        writer.println("ERROR: Erroneous command!");
                                    }
                                    break;
                                default:
                                    writer.println("ERROR: Erroneous command!");
                            }
                            if (allOK) {
                                //add the device to the device list
                                mySmartHomeSystem.addDevice(lamp);
                            }
                            break;

                        case "SmartColorLamp":
                            SmartColorLamp Clamp = new SmartColorLamp();
                            switch (commandLine.length) {
                                case 3:
                                    // Set name and default status
                                    Clamp.setName(commandLine[2]);
                                    allOK &= Clamp.setDeviceStatus(deviceStatus.off);
                                    break;
                                case 4:
                                    // Set name
                                    Clamp.setName(commandLine[2]);

                                    // Check and set initial status
                                    switch (commandLine[3]) {
                                        case "On":
                                            allOK &= Clamp.setDeviceStatus(deviceStatus.on);
                                            break;
                                        case "Off":
                                            allOK &= Clamp.setDeviceStatus(deviceStatus.off);
                                            break;
                                        default:
                                            writer.println("ERROR: Erroneous command!");
                                            allOK &= false;
                                    }
                                    break;
                                case 6:
                                    // Set name
                                    Clamp.setName(commandLine[2]);

                                    // Check and set initial status
                                    switch (commandLine[3]) {
                                        case "On":
                                            allOK &= Clamp.setDeviceStatus(deviceStatus.on);
                                            break;
                                        case "Off":
                                            allOK &= Clamp.setDeviceStatus(deviceStatus.off);
                                            break;
                                        default:
                                            writer.println("ERROR: Erroneous command!");
                                            allOK &= false;
                                    }

                                    //Check and set whichever of the kelvin or color code value is included in the command
                                    if (commandLine[4].startsWith("0x")) {
                                        try {
                                            allOK &= Clamp.setColorCode(Integer.parseInt(commandLine[4].substring(2), 16));
                                        } catch (Exception e) {
                                            allOK &= false;
                                            writer.println("ERROR: Erroneous command!");
                                        }

                                    } else {
                                        try {
                                            allOK &= Clamp.setKelvin(Integer.parseInt(commandLine[4]));
                                        } catch (Exception e) {
                                            allOK &= false;
                                            writer.println("ERROR: Erroneous command!");
                                        }
                                    }

                                    // Check and set brightness
                                    if (allOK){
                                        allOK &= Clamp.setBrightness(Integer.parseInt(commandLine[5]));
                                    }

                                    break;
                                default:
                                    writer.println("ERROR: Erroneous command!");
                            }
                            if (allOK) {
                                //add the device to the device list
                                mySmartHomeSystem.addDevice(Clamp);
                            }

                    }
                    break;
                case "Remove":
                    mySmartHomeSystem.removeDevice(commandLine[1]);
                    break;
                case "SetWhite": {
                    SmartDevice device;
                    String name = commandLine[1];
                    device = mySmartHomeSystem.getDevice(name);
                    if (device == null) {
                        writer.println("ERROR: There is not such a device!");

                    } else {
                        if(device.isSmartLamp()) {
                            try {
                                device.setWhite(Integer.parseInt(commandLine[2]), Integer.parseInt(commandLine[3]));
                            } catch (Exception e) {
                                writer.println("ERROR: Erroneous command!");
                            }
                        } else {
                            writer.println("ERROR: This device is not a smart lamp!");
                        }

                    }
                    break;
                }
                case "SetKelvin": {
                    SmartDevice device;
                    String name = commandLine[1];
                    device = mySmartHomeSystem.getDevice(name);
                    if (device == null) {
                        writer.println("ERROR: There is not such a device!");

                    } else {
                        if (device.isSmartLamp()) {
                            try {
                                device.setKelvin(Integer.parseInt(commandLine[2]));
                            } catch (Exception e) {
                                writer.println("ERROR: Erroneous command!");
                            }
                        } else {
                            writer.println("ERROR: This device is not a smart lamp!");
                        }

                    }
                    break;
                }
                case "SetBrightness": {
                    SmartDevice device;
                    String name = commandLine[1];
                    device = mySmartHomeSystem.getDevice(name);
                    if (device == null) {
                        writer.println("ERROR: There is not such a device!");

                    } else {
                        if (device.isSmartLamp()) {
                            try {
                                device.setBrightness(Integer.parseInt(commandLine[2]));
                            } catch (Exception e) {
                                writer.println("ERROR: Erroneous command!");
                            }
                        } else {
                            writer.println("ERROR: This device is not a smart lamp!");
                        }

                    }
                    break;
                }
                case "SetColorCode":{
                    SmartDevice device;
                    String name = commandLine[1];
                    device = mySmartHomeSystem.getDevice(name);
                    if (device == null) {
                        writer.println("ERROR: There is not such a device!");

                    } else {
                        if (device.isSmartColorLamp()) {
                            try {
                                device.setColorCode(Integer.parseInt(commandLine[2].substring(2), 16));
                            } catch (Exception e) {
                                writer.println("ERROR: Erroneous command!");
                            }
                        } else {
                            writer.println("ERROR: This device is not a smart color lamp!");
                        }

                    }
                    break;
                }
                case "SetColor":{
                    SmartDevice device;
                    String name = commandLine[1];
                    device = mySmartHomeSystem.getDevice(name);
                    if (device == null) {
                        writer.println("ERROR: There is not such a device!");

                    } else {
                        if (device.isSmartColorLamp()) {

                            try {
                                device.setColor(Integer.parseInt(commandLine[2].substring(2), 16), Integer.parseInt(commandLine[3]));
                            } catch (Exception e) {
                                writer.println("ERROR: Erroneous command!");
                            }
                        } else {
                            writer.println("ERROR: This device is not a smart color lamp!");
                        }

                    }
                    break;
                }
                case "SetSwitchTime":{
                    SmartDevice device;
                    String name = commandLine[1];
                    device = mySmartHomeSystem.getDevice(name);
                    if (device == null) {
                        writer.println("ERROR: There is not such a device!");

                    } else {
                        try {
                            device.setSwitchTime(LocalDateTime.parse(commandLine[2], DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss")));
                        } catch (Exception e) {
                            writer.println("ERROR: Erroneous command!");
                        }
                    }
                    break;
                }
                case "Switch":{
                    SmartDevice device;
                    String name = commandLine[1];
                    device = mySmartHomeSystem.getDevice(name);
                    if (device == null) {
                        writer.println("ERROR: There is not such a device!");

                    } else {

                        switch (commandLine[2]) {
                            case "On":
                                device.setDeviceStatus(deviceStatus.on);
                                break;
                            case "Off":
                                device.setDeviceStatus(deviceStatus.off);
                                break;
                            default:
                                writer.println("ERROR: Erroneous command!");
                        }

                    }
                    break;

                }
                case "PlugIn":{
                    if (commandLine.length == 3){
                        SmartDevice device;
                        String name = commandLine[1];
                        device = mySmartHomeSystem.getDevice(name);
                        if (device == null) {
                            writer.println("ERROR: There is not such a device!");

                        } else {
                            if (device.isSmartPlug()) {
                                try {
                                    device.plugIn(Float.parseFloat(commandLine[2]));
                                } catch (Exception e) {
                                    writer.println("ERROR: Erroneous command!");
                                }
                            } else {
                                writer.println("ERROR: This device is not a smart plug!");
                            }

                        }
                    }
                    else{
                        writer.println("ERROR: Erroneous command!");
                    }

                    break;
                }
                case "PlugOut":{
                    if (commandLine.length == 2){
                        SmartDevice device;
                        String name = commandLine[1];
                        device = mySmartHomeSystem.getDevice(name);
                        if (device == null) {
                            writer.println("ERROR: There is not such a device!");

                        } else {
                            device.plugOut();
                        }
                    }else{
                        writer.println("ERROR: Erroneous command!");

                    }

                }
                break;
                case "ChangeName":{
                    try{
                        SmartDevice device;
                        String name = commandLine[1];
                        String newName = commandLine[2];
                        mySmartHomeSystem.changeName(name, newName);
                    }catch (ArrayIndexOutOfBoundsException e){
                        writer.println("ERROR: Erroneous command!");
                    }

                }
                break;
                case "ZReport":
                    lastZReport = true;
                    mySmartHomeSystem.printReport();
                    break;
                case "":
                    break;
                default:
                    writer.println("ERROR: Erroneous command!");

            }

        }

        if (!lastZReport){
            writer.println("ZReport:");
            mySmartHomeSystem.printReport();
        }


        writer.close();
    }

    /**
     *A method that reads a text file and returns its contents as an array of strings.
     *@param path the name of the file to read
     *@return an array of strings representing the lines of the file
     *@throws IOException if an I/O error occurs while reading the file
     */
    public static String[] readFile(String path) {
        try {
            int i = 0;
            int lenght = Files.readAllLines(Paths.get(path)).size();
            String[] results = new String[lenght];
            for (String line : Files.readAllLines(Paths.get(path))) {
                results[i++] = line;
            }
            return results;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}