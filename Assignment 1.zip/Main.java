import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;



public class Main {

    public static void main(String[] args) {

        String[] lines_board = readFile(args[0]);
        String[] lines_move = readFile(args[1]);

        int numRows = lines_board.length;
        int numColumns = (lines_board[0].length())/2 + 1;
        int numCommands = (lines_move[0].length())/2 + 1;

        String[][] board = new String[numRows][numColumns];

        for (int i = 0; i< numRows; i++){
            String line = lines_board[i].toString();
            String lineString = Arrays.toString(line.split(" "));
            String charsToDelete = "[ ] ,  ";
            char[] charArray = charsToDelete.toCharArray();
            for (char c : charArray) {
                lineString = lineString.replace(Character.toString(c), "");
            }

            for (int j = 0; j<numColumns; j++){
                board[i][j] = String.valueOf(lineString.charAt(j));

            }
        }

        String[] commands = new String[numCommands];

        String line = lines_move[0].toString();
        String moveString = Arrays.toString(line.split(" "));
        String charsToDelete = "[ ] ,  ";
        char[] charArray = charsToDelete.toCharArray();
        for (char c : charArray) {
            moveString = moveString.replace(Character.toString(c), "");
        }
        for (int i = 0; i<numCommands; i++){
            commands[i] = String.valueOf(moveString.charAt(i));

        }


        int[] idxTarget = {0, 0};

        int score = 0;

        //create an array to collect commands executed
        String[] commandsExecuted = new String[0];


        for (String command: commands){

            //add each executed command to the array called commandsExecuted
            String[] newArr = new String[commandsExecuted.length + 1];
            System.arraycopy(commandsExecuted, 0, newArr, 0, commandsExecuted.length);
            newArr[newArr.length - 1] = command;
            commandsExecuted = newArr;

            // find the indices of the "*"
            int rowIdx = findIndex(board)[0];
            int colIdx = findIndex(board)[1];


            //determine indices of target cells and store them in an int array called "idxTarget"
            if (command.equals("R")){
                if (colIdx == numColumns -1){
                    idxTarget = new int[] {rowIdx, 0};
                }else{
                    idxTarget =new int[] {rowIdx, colIdx + 1};
                }

            }else if (command.equals("L")){
                if (colIdx == 0){
                    idxTarget = new int[] {rowIdx, numColumns -1};
                }else{
                    idxTarget = new int[] {rowIdx, colIdx - 1};
                }

            }else if (command.equals("U")){
                if (rowIdx == 0){
                    idxTarget = new int[] {numRows - 1, colIdx};
                }else{
                    idxTarget = new int[] {rowIdx - 1, colIdx};
                }

            }else if ( command.equals("D")){
                if (rowIdx == numRows - 1){
                    idxTarget = new int[] {0, colIdx};
                }else{
                    idxTarget = new int[] {rowIdx + 1, colIdx};
                }

            }

            //change the indices of target cell to opposite direction in case of hitting the wall
            if (board[idxTarget[0]][idxTarget[1]].equals("W")){
                if(command.equals("R")) {
                    if (colIdx == 0) {
                        idxTarget = new int[]{rowIdx, numColumns - 1};
                    } else {
                        idxTarget = new int[]{rowIdx, colIdx - 1};
                    }
                }else if(command.equals("L")){
                    if (colIdx == numColumns -1){
                        idxTarget = new int[] {rowIdx, 0};
                    }else{
                        idxTarget =new int[] {rowIdx, colIdx + 1};
                    }

                }else if(command.equals("U")){
                    if (rowIdx == numRows - 1){
                        idxTarget = new int[] {0, colIdx};
                    }else{
                        idxTarget = new int[] {rowIdx + 1, colIdx};
                    }

                }else if(command.equals("D")){
                    if (rowIdx == 0){
                        idxTarget = new int[] {numRows - 1, colIdx};
                    }else{
                        idxTarget = new int[] {rowIdx - 1, colIdx};
                    }

                }
            }

            if (board[idxTarget[0]][idxTarget[1]].equals("H")){
                board[rowIdx][colIdx] = " ";
                break;
            }
            int rowTarget = idxTarget[0];
            int colTarget = idxTarget[1];

            switch(board[rowTarget][colTarget]){
                case "G":
                case "P":
                case "O":
                case "D":
                case "L":
                case "F":
                case "N":
                    board[rowIdx][colIdx] = board[rowTarget][colTarget];
                    board[rowTarget][colTarget] = "*";
                    break;

                case "X":
                    board[rowIdx][colIdx] = "X";
                    board[rowTarget][colTarget] = "*";
                    break;
                case "R":
                    board[rowIdx][colIdx] = "X";
                    board[rowTarget][colTarget] = "*";
                    score = score +10;
                    break;

                case "Y":
                    board[rowIdx][colIdx] = "X";
                    board[rowTarget][colTarget] = "*";
                    score = score + 5;
                    break;
                case "B":
                    board[rowIdx][colIdx] = "X";
                    board[rowTarget][colTarget] = "*";
                    score = score - 5;
                    break;

            }


        }

        //create an output file to print the results
        String fileName = "output.txt";

        try {
            PrintWriter writer = new PrintWriter(fileName);

            writer.println("Game board:");

            for (int i = 0; i < lines_board.length; i ++){
                writer.println(lines_board[i] + " ");
            }
            writer.println();
            writer.println("Your movement is:");
            for (int i = 0; i< commandsExecuted.length; i++){
                writer.print(commandsExecuted[i] + " ");
            }
            writer.println();
            writer.println();
            writer.println("Your output is:");

            for (int i = 0; i < board.length; i++) {
                for (int j = 0; j < board[i].length; j++) {
                    writer.print(board[i][j] + " ");
                }
                writer.println();
            }
            writer.println();
            writer.println("Game Over!");
            writer.print("Score: " + score);
            writer.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static String[] readFile(String path) {
        try {
            int i = 0;
            int lenght = Files.readAllLines(Paths.get(path)).size();
            String[] results = new String[lenght];
            for (String line : Files.readAllLines(Paths.get(path))) {
                results[i++] = line;
            }
            return results;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    //creates a method to find the location of white ball
    public static int[] findIndex(String[][] board) {

        String target = "*";
        int[] index = new int[2];

        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j].equals(target)) {
                    index[0] = i;
                    index[1] = j;
                    return index;
                }
            }
        }

        return null;
    }

}